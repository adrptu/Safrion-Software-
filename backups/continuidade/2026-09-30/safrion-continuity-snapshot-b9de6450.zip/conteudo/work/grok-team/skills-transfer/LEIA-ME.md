# Skills de design do Safrion — pacote para Grok

**Pacote preparado para transferência. Não está instalado no Grok e não comprova que Grok leu, aplicou ou validou estas skills.** O responsável fará o upload pelo canal oficial. Este pacote não contém instalador, hooks de instalação nem configuração de conector; nada foi instalado ou executado para ativar as skills.

Os arquivos em `skills/` são cópias byte a byte das fontes locais identificadas no [manifesto](manifesto.json). As seis skills e seus exemplos foram preservados. O único arquivo adicional de outra skill é a dependência local [tsconfig.strict.json](skills/dev-revisao/assets/tsconfig.strict.json), referenciada por `dev-frontend-mobile`; a skill `dev-revisao` inteira não foi incluída.

## Uso por tarefa

| Tarefa | Referência |
|---|---|
| Agrupar menus por domínio, localizar registros e preservar listagem/detalhe/contexto | [master-detail-ux](skills/master-detail-ux/SKILL.md) |
| Desenhar jornada, ações, formulários, retorno visual, acessibilidade e recuperação | [ux-essencial](skills/ux-essencial/SKILL.md) |
| Cortar duplicações e passos sem perder controles, informação necessária ou tarefas sazonais | [minimalismo-essencial](skills/minimalismo-essencial/SKILL.md) |
| Revisar filtros, ordenação, agrupamento, detalhe e edição das tabelas | [tabelas-interativas](skills/tabelas-interativas/SKILL.md) |
| Implementar a interface respeitando estado, permissões, desempenho e sincronização | [dev-frontend-mobile](skills/dev-frontend-mobile/SKILL.md) |
| Escolher e registrar provas proporcionais aos comportamentos e riscos alterados | [dev-testes](skills/dev-testes/SKILL.md) |

## Aplicação no projeto existente

- O PRD e o design system vigente do Safrion são as fontes do produto. **Os tokens, componentes, vocabulário e contratos Safrion prevalecem sobre os exemplos Material Design 3.** Exemplos não são componentes certificados nem autorização para substituir a arquitetura, instalar bibliotecas ou criar outra metodologia/fila.
- Na tarefa atual, reutilizar o protótipo existente e a divisão de autoria/revisão combinada com a equipe. Os requisitos de navegação da Fase 1 e o protocolo da equipe continuam no registro canônico do projeto; não estão duplicados neste pacote.
- As configurações de Vitest, Playwright, pytest e TypeScript são exemplos para adaptação, não uma suíte pronta nem indicação de testes executados. Caminhos como `src/test/setup.ts`, `e2e/.auth/user.json`, `tests` e `app` pertencem ao projeto de destino e não são fornecidos aqui. Os imports de pacotes não foram instalados.
- Os exemplos HTML/M3 mantêm referências externas a Google Fonts. As URLs web não foram acessadas nem verificadas; o pacote não promete fontes totalmente offline. Os assets locais referenciados estão incluídos e os links relativos foram verificados.
- `indicadores-satelite` não foi incluída: o contrato C4 vigente continua prevalecendo e o recorte atual é navegação.

## Integridade e limites

`manifesto.json` identifica origem, função, bytes e SHA-256 de cada arquivo de conteúdo. O manifesto não inclui o próprio hash para evitar autorreferência; seu hash e o do ZIP ficam no recibo local de validação, fora do ZIP. A inspeção estática de padrões sensíveis não é uma auditoria exaustiva. Preparação e integridade do pacote não equivalem a instalação, revisão ou aceite por Grok.
