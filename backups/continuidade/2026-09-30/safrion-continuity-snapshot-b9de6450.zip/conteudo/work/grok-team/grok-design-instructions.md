Codex → Grok, a pedido expresso de Adrianus: potencializar design, UX e UI para a Fase 1. Este é um reforço operacional da tarefa NAV-F1-A existente, não uma nova fila.

O upload pelo seletor de arquivo não respondeu. Seguem abaixo os seis SKILL.md completos e fiéis, para leitura e aplicação neste workspace. Os assets/referências do ZIP NÃO foram transmitidos nesta mensagem; não afirme que recebeu/instalou o ZIP. ZIP preparado: fe68785817d85996ad626d07886e3a385cfb80c4f8496f1b6ced1293ab8d1d33. Se este Build suporta descoberta de skills locais, salve cada texto entre os delimitadores no diretório documentado adequado sem sobrescrever instruções existentes; caso contrário, aplique-os como instruções da tarefa e declare o limite. Exemplos que dependem de assets não anexados não devem ser importados. PRD, contrato C4, componentes/tokens do Safrion e nossas autorizações prevalecem sobre exemplos M3 e sugestões de stack. Não instalar uma coleção de ferramentas nem trocar stack por causa da skill.

Recebi NAV-F1-A, resposta9ec18ee3-946a-49b2-bdf8-46d6aef4e697. Há hashes e relato de tsc/Playwright; a entrega ainda está em revisão, sem homologação funcional ou publicação. Antes de nova edição faça snapshot recuperável das cinco fontes entregues e dos próximos arquivos que tocar, manifeste hashes; confirme que consegue recuperar por arquivo. Não recrie shell por inteiro; patches pequenos, leitura/diff e conferência de alvo após cada escrita. Preserve fonte, registros, seed, roteiros, store e regras. Não reinicialize a demonstração. Nenhum segredo, conta, novo serviço pago, rotina, produção ou envio a outro provedor.

Aplique as skills à mesma tarefa e corrija apenas os achados materiais:
1. Meu dia ainda oferece monitoramento cujo clique termina no aviso de Fase2. O mapa ainda mostra praga/déficit/colheita futuros. O pedido é ocultar temporariamente futuros também nessas entradas, preservando dados e referências agronômicas necessárias ao planejamento. Registre arquivos adicionais e escopo antes de editar.
2. CD07 Estrutura gerencial não pode desaparecer por inteiro se é o acesso a naturezas, centros e dimensões usados no custo da Fase1. Mantenha acesso contextual coerente com as permissões, sem adiantar orçamento/financeiro. CD03 máquinas/custos-hora e operações futuras usadas no planejamento continuam necessárias. Relate qual acesso concreto preservou.
3. Abrir a ordem no talhão deve selecionar a O.S. correta, e voltar preservar talhão/filtros. Teste dois talhões e duas O.S.; chegar somente a /agricola/ordens não demonstra esse comportamento. Não invente comandos de execução ainda indisponíveis.
4. Verifique teclado/foco, menu no celular, alvo de toque, contraste, zoom200%, erro/vazio/pendência e labels no trecho alterado. Reutilize Playwright instalado. Use axe se já disponível; se ausente e instalação oficial local pequena realmente ajudar, identifique versão/dependência e valide, sem serviço externo. Automatizado não substitui avaliação visual nem VoiceOver real. Não repita bateria intacta.
5. Revise hierarquia visual, tipografia, densidade e consistência com DS Safrion, uma ação primária/contexto, sem polimento decorativo. Medir sucesso da tarefa, erros, cliques/digitação estritamente necessários e tempo observado com condições; não alegar ganho por contagem isolada.

Devolva ACK dos seis textos e modo real de uso/descoberta; inventário breve das ferramentas de design/teste efetivamente disponíveis neste Build; fontes alteradas + hashes + diff e script/logs brutos para revisão independente, preferencialmente exportação limitada aos arquivos da tarefa e manifesto (sem node_modules/segredos/dados reais). Não afirmar conector GitHub, Figma, API ou skill descoberta automaticamente sem prova. Claude implementa backend e Codex/Gemini revisam contratos em paralelo; esta revisão de UI não bloqueia esse trabalho.


===== INÍCIO skills/master-detail-ux/SKILL.md =====
---
name: master-detail-ux
description: Organize entidades de gestão em Menu, Listagem, Detalhe e Sub-detalhe, com estado visível, próximo passo e contexto preservado. Use ao criar ou revisar módulos, cadastros, navegação, telas e fluxos de gestão.
---

# Master-detail: localizar, entender e agir

**Menu → Listagem → Detalhe → Sub-detalhe.** Toda entidade de gestão tem listagem e detalhe. A estrutura organiza o trabalho; não exige adicionar componentes sem função.

## Princípios

1. **Estado visível:** mostrar a situação com vocabulário consistente e texto, sem depender só de cor. Barra de etapas e percentual apenas quando representam progresso real e ajudam a decidir.
2. **Próximo passo com verbo:** indicar a ação adequada ao estado e à permissão. Deixar claro onde está no processo, o que falta e como avançar. Se estiver impedida, mostrar a causa e quem pode resolver, sem oferecer execução inválida. Avançar conserva o contexto e não dispara sozinho a operação da etapa seguinte.
3. **Uma ação primária por tela:** posição consistente e acessível. Secundárias junto do conteúdo a que pertencem; destrutivas separadas. Manter a primária alcançável em tela longa; repetir em rodapé apenas se a distância justificar, sem cobrir dados, campo ativo, teclado virtual ou controles. Conferir toque, teclado e posição após erros.
4. **Contexto preservado:** título, vínculo ao pai e retorno claro; voltar conserva filtros, posição e estado útil. Detalhe pode ser página ou painel acessível, com referência estável.
5. **Vocabulário e cores consistentes:** usar os mesmos nomes e tokens do design system para o mesmo significado; classificação não se confunde com estado.

## Por nível

- **Menu:** entidades agrupadas por tarefa/domínio; localização atual evidente e acesso conforme permissão.
- **Listagem:** localizar e comparar registros; identificação, estado, informação que determina a escolha e próximo passo. Ações rápidas são permitidas quando simples, autorizadas e coerentes com o processo, sem eliminar o detalhe. Tabelas seguem `tabelas-interativas`.
- **Detalhe:** executar no contexto da entidade; cabeçalho, estado, ação primária e seções necessárias. Indicadores, stepper, resumo e explicação aparecem somente se ajudam a decisão; não são quotas obrigatórias.
- **Sub-detalhe:** aprofundar um item preservando vínculo ao pai; mostrar dados, ações e totais que façam sentido nesse recorte.

Anatomia e exemplos em [references/anatomia.md](references/anatomia.md), quando precisar desenhar os níveis.

## Aplicação

Em módulo novo, antes de código, mostre uma tabela curta com entidades, estados, ação primária por estado e seções do detalhe. Siga sem esperar aprovação, salvo dúvida que mude materialmente o desenho. Em sistema existente, identifique entidade/nível e reaproveite o padrão; não refatore frentes alheias ao pedido.

Rotas refletem a entidade e seu detalhe (`/entidades`, `/entidades/:id`) conforme o roteador do projeto. Estado navegável pode ir à URL, mas nunca segredos ou conteúdo sensível. Criação rápida mantém contexto e oferece acesso imediato ao registro criado.

Login, onboarding, landing page, wizard linear, configuração simples e pagamento podem não representar entidades de gestão; aplique `ux-essencial` e explique em uma frase por que o master-detail não se aplica.

## Encerramento

Passe o [checklist](references/checklist.md) e o corte de `minimalismo-essencial`. Entregue três listas curtas: aplicado, deixado de fora e cortado, com motivo. Não remover estado, próximo passo, retorno, acessibilidade ou controles necessários para tornar a tela menor.

===== FIM skills/master-detail-ux/SKILL.md =====


===== INÍCIO skills/ux-essencial/SKILL.md =====
---
name: ux-essencial
description: Desenhe e revise interfaces e fluxos simples, acessíveis e rápidos, com contexto confiável e prevenção de erro. Use em telas, formulários, navegação, microcopy e retorno visual; preserve comandos e aprovações necessários.
---

# UX Essencial — o sistema como braço direito

**Norte:** o usuário chega, faz o que veio fazer no menor tempo possível, sem pensar, sem medo de errar, e sai com a sensação de que o sistema trabalhou por ele.

Teste de cada tela: **"Qual é a única coisa que a pessoa veio fazer aqui? Ela consegue fazer isso agora, com o mínimo de passos?"** Se não, redesenhe antes de codar.

---

## 1. Processo — pensar antes de desenhar
1. **Tarefa principal** de cada tela em uma frase ("Registrar pedido de um cliente conhecido").
2. **Fluxo mínimo**: conte passos/campos e reduza esforço sem perder compreensão, acessibilidade, segurança e controles do processo.
3. **O que o sistema pode fazer pelo usuário?** Reutilizar contexto confiável e sugerir valores editáveis; inferência não substitui aprovação nem inventa dose, quantidade, identidade ou responsável.
4. Construir com o design system vigente; usar os exemplos deste guia quando não houver um padrão do projeto.
5. Revisar com o **checklist final**. Em projeto real, medir com HEART (Felicidade, Engajamento, Adoção, Retenção, **Sucesso na tarefa**: taxa de conclusão, tempo, erros).

## 2. Leis da fricção zero
**Menos passos**
- **Uma ação primária por tela**, óbvia (botão preenchido ou FAB). Secundárias discretas (tonal/texto). Nunca duas primárias.
- A tarefa mais frequente fica **na primeira tela, sem navegar**. Nada de "home" decorativa: a home é o trabalho (lista, caixa de entrada, próximo passo).
- **Padrões inteligentes**: lembrar escolhas no contexto correto de pessoa, empresa, fazenda e safra; mostrar o valor e permitir revisão. Data atual e usuário logado não são necessariamente data da operação e executor.
- **Autocompletar com fonte**: cadastro autorizado → entidade/unidade/preço vigente; quantidade × preço → total calculado. Não inferir nome/identidade pelo e-mail. Seleções mostram dados suficientes para distinguir homônimos.
- **Criação rápida inline**: campo "Adicionar…" + Enter. Detalhes opcionais depois, na própria linha.
- **Edição inline** (clicar no valor e editar). Modal só para fluxo realmente separado.
- **Ações em massa** quando há tarefa real repetitiva, permissões verificadas e efeito claro.
- Autenticação antes de acessar dados protegidos; duração de sessão conforme risco e contexto. Não enfraquecer segurança para reduzir cliques.
- **Sem tour/onboarding de slides**: estado vazio ensina com uma ação ("Nenhum cliente ainda · Importar planilha · Adicionar cliente").

**Sem medo, sem burocracia**
- **Desfazer** para operações reversíveis de baixo risco. Ações irreversíveis ou de impacto material mostram consequência e confirmação apropriada. A IA respeita toda aprovação específica exigida pelo usuário/projeto.
- **Salvamento automático de rascunhos**, com estado verdadeiro. Confirmar recebimento, movimentar estoque, publicar, pagar ou executar uma ordem são comandos explícitos; não disparam ao sair de um campo.
- **Nunca perder o que foi digitado** (rascunho local, erro de rede não limpa o formulário, voltar mantém o estado).
- **Validação inline** ao sair do campo, com mensagem que diz **como corrigir** ("Use 11 dígitos: DDD + número"). Máscaras que aceitam colar em qualquer formato. Nunca bloquear o botão sem dizer o porquê.

**Formulários**
- Campos da mesma tarefa compartilham contexto e sequência natural de teclado/toque; autocomplete e cálculos dependentes atualizam no lugar, sem perda de foco. Não exigir salvar cada campo/seção para concluir uma única operação.
- Uma confirmação clara para a operação completa; itens interdependentes exigem atomicidade no servidor. Etapas separadas só quando representam estados, permissões ou operações reais, com continuidade visível. Ações em lote seguem a semântica do domínio; sucesso parcial identifica itens concluídos e pendentes.
- Uma coluna, ordem lógica da vida real, rótulos sempre visíveis (sem placeholder como rótulo).
- Só o essencial; o resto em "Mais opções" (divulgação progressiva).
- `type`, `inputmode` e `autocomplete` corretos. Enter seleciona sugestão aberta ou executa a ação previsível; nunca confirma transação por acidente.
- Datas com atalhos ("Hoje", "Amanhã", "+7 dias"); selects longos viram busca com autocompletar.

**Encontrar e agir rápido**
- Busca contextual acessível; busca global e paleta Ctrl/⌘+K quando reduzem esforço real. Atalhos complementam controles visíveis.
- **Atalhos de teclado** para as ações frequentes (N = novo, / = buscar, E = editar, Esc = fechar), exibidos nos tooltips e na paleta.
- **URL reflete o estado** (filtros, aba, item aberto): dá para compartilhar, recarregar e voltar sem perder nada.
- Navegação: **3 a 5 destinos principais**, profundidade máxima de 3 níveis, caminho sempre visível.
- **Organização das telas** segue a skill **`master-detail-ux`** (Menu → Listagem → Detalhe → Sub-detalhe; estado visível, próximo passo nomeado, uma ação primária por tela).
- **Tabelas** seguem a skill **`tabelas-interativas`** (filtro e ordenação no cabeçalho, agrupamento, drill-down).

**Notificações e mensagens**
- Só notifica o que exige ação, com a ação no próprio aviso.
- Erros: o que houve + o que fazer, em linguagem humana, sem códigos. Sucesso discreto (snackbar), nunca modal.

## Continuidade sem esforço — Wu wei

No Safrion, fluidez significa continuidade da tarefa, não movimento decorativo. O usuário deve entender onde está, o estado do trabalho e o próximo passo sem depender de explicação do agente.

- Herdar fazenda, safra, talhão e tarefa quando o contexto for confiável; não perguntar de novo nem trocar contexto silenciosamente.
- Preservar busca, filtros, rolagem, seleção, rascunho e foco no retorno; ao reabrir o app, recuperar o ponto de trabalho dentro da sessão e do escopo autorizados. Após salvar, atualizar no lugar e oferecer o próximo passo pertinente; não redirecionar nem executar uma nova ação sem intenção.
- Evitar saltos de layout, modais em sequência e recarregamentos que apagam o trabalho. Responder ao toque de imediato e mostrar junto do objeto processamento, pendência, conclusão real ou erro com o que fazer. Usar as palavras de estado do design system (Safrion: PRD 74.4.3), com texto e sinal visual, sem depender só de cor ou aviso temporário. Impedir repetição do comando em processamento sem bloquear trabalho independente; erro mantém os dados e uma saída clara. Salvo no aparelho não significa aceito pelo servidor.
- Autocomplete distingue entidades semelhantes, funciona com teclado/toque e informa ausência de resultado. Não exigir sintaxe técnica para pesquisar ou filtrar.
- No campo, priorizar a tarefa da persona, legibilidade sob sol, alvos acessíveis, pouca digitação e conexão intermitente. Testar no dispositivo e nas condições-alvo; desktop rápido não comprova fluidez no campo.
- Som e movimento são discretos e dispensáveis; respeitar preferências, redução de movimento e o vocabulário do design system. Não emitir som repetido em sincronização de fundo nem depender de áudio para comunicar sucesso/erro.
- Antes do aceite, verificar uma jornada principal, retorno/correção e erro/recuperação por persona afetada. Usar automação para regressões e observação humana para entendimento. Medir tempo, sucesso, erros e esforço com contexto; não afirmar superioridade sem comparação.

Texto ambíguo que provoca erro, perda de contexto/rascunho, confirmação falsa de sucesso e caminho sem recuperação são defeitos de usabilidade, não mero polimento. Não retirar aprovações ou controles necessários para reduzir cliques; torná-los claros e proporcionais.

## 3. Resposta imediata (performance é UX)

| Momento | Regra |
|---|---|
| < 100 ms | Todo clique dá retorno visual imediato (camada de estado, item muda na hora) |
| Ações do usuário | Retorno visual imediato; UI otimista só quando o efeito é reversível e o estado pendente é claro. Não mostrar aceite do servidor antes do recibo |
| > 300 ms | **Skeleton** no formato do conteúdo (nunca spinner de tela cheia) |
| > 1 s | Progresso/estado explícito; > 10 s: roda em segundo plano e avisa quando terminar |
| Web Vitals (Google) | **LCP < 2,5 s · INP < 200 ms · CLS < 0,1** no percentil 75 |

Técnicas: pré-carregar a próxima tela provável, cache local (stale-while-revalidate), paginação/virtualização acima de ~200 itens, debounce 150–300 ms em buscas, imagens com dimensão definida (sem pulos de layout), carregar o que está acima da dobra primeiro, JS mínimo.

## 4. Visual — referência Material Design 3
O design system do projeto prevalece; os padrões M3 desta seção e as sugestões de plataforma abaixo valem somente na ausência dele. Não substituir tokens, tipografia ou componentes já definidos.

Exemplos: **[assets/m3.css](assets/m3.css)**, **[assets/m3-kit.js](assets/m3-kit.js)** e **[assets/exemplo.html](assets/exemplo.html)**. Inspecione acessibilidade, segurança e compatibilidade antes de reutilizar; não são componentes certificados nem substituem o design system vigente. Respeite a política de recursos externos do ambiente.

- **Cor por papéis** (`primary`, `on-primary`, `secondary-container`, `surface-container-*`, `on-surface-variant`, `outline`, `error`) — nunca hex solto no componente. Paleta padrão GM3 azul; para a marca, gerar o esquema no Material Theme Builder e trocar só os tokens. **Uma cor de destaque**; o resto são superfícies neutras. Claro e escuro sempre.
- **Tipografia**: escala M3 (Display, Headline, Title, Body, Label); Roboto Flex/Roboto; **sentence case** em títulos e botões ("Criar pedido", não "CRIAR PEDIDO" nem "Criar Pedido"). Máx. 2–3 tamanhos por tela.
- **Espaço**: grade de 4/8 px; respiro generoso separa grupos melhor que linhas e caixas.
- **Forma**: 4 (campos) · 8 (chips) · 12 (cards) · 16 (FAB) · 28 (diálogos) · pílula (botões).
- **Elevação** tonal (superfícies mais claras/escuras); sombra só em elementos flutuantes (FAB, menu, snackbar).
- **Movimento** funcional: 150–400 ms, easing *emphasized*; respeitar `prefers-reduced-motion`.
- **Ícones**: Material Symbols Rounded, sempre com rótulo ou tooltip; preenchido = ativo.
- **Componentes**: botão filled (primária) · tonal (secundária importante) · outlined/text (demais) · FAB (criar) · chips (filtros) · snackbar (retorno) · cards só quando agrupam algo clicável · diálogos raros.
- **Layout adaptativo (classes de janela M3)**: compacto < 600 px → barra de navegação inferior; médio 600–839 → navigation rail; expandido ≥ 840 → rail/drawer + painéis lista-detalhe lado a lado. Densidade maior em desktop para dados.

## 5. Minimalismo e essencialismo
A lei de corte completa (5 testes de essencialidade, orçamentos por tela, lista de proibidos, procedimento de corte e lista de cortes na entrega) está na skill **`minimalismo-essencial`** — aplicar sempre, ao fechar toda tela.
- Para cada elemento: **"se eu remover, alguém sente falta?"** Se não, remove.
- Nada decorativo: sem ilustrações de enfeite, gradientes, sombras gratuitas, textos de boas-vindas, ícones sem função.
- **Hierarquia clara**: o olho cai primeiro na informação/ação principal; secundário em `on-surface-variant`.
- **Divulgação progressiva**: avançado escondido até ser necessário, mas a um clique.
- **Microcopy**: frases curtas, voz ativa, palavras do usuário (não do banco de dados), botões com verbo + objeto, números formatados em pt-BR, datas relativas quando úteis ("há 5 min", "amanhã").

## 6. Acessibilidade e inclusão (WCAG 2.2 AA)
Contraste ≥ 4,5:1 (texto) e 3:1 (componentes) · foco sempre visível · tudo operável por teclado · alvos de toque conforme o design system e a plataforma; na ausência de padrão, ≥ 48×48 px · rótulos e `aria-*` corretos · não depender só de cor · `lang="pt-BR"` · zoom 200% sem quebrar.

## 7. Plataformas
Na ausência de design system do projeto, usar as referências abaixo, respeitando a stack e as convenções já adotadas.
- **Web (HTML/React/Vue/Next)**: `m3.css` + `m3-kit.js` ou tokens M3 mapeados no Tailwind/CSS do projeto. Evite `@material/web` (em modo de manutenção). MUI só se já existir no projeto, ajustando tema para M3.
- **Android**: Jetpack Compose Material 3. **Multiplataforma**: Flutter com `useMaterial3: true` e `ColorScheme.fromSeed`.
- **iOS**: manter os princípios deste guia, respeitando convenções nativas (navegação, gestos).

---

## Checklist final (toda entrega)
- [ ] Tarefa principal identificável em 1 segundo; **uma** ação primária
- [ ] Fluxo mínimo preserva significado, controles, unidades e aprovações
- [ ] Contexto e sugestões confiáveis, visíveis e revisáveis
- [ ] Rascunho preservado; autosave/desfazer só onde apropriados; comandos de negócio explícitos
- [ ] Validação inline com instrução de correção; tarefa com vários campos, correção de erro e retorno à lista verificados sem fragmentar a operação nem perder contexto
- [ ] Busca/atalhos pertinentes e estado de navegação preservado sem dados sensíveis na URL
- [ ] Retorno imediato; estado local/pendente/aceito correto; desempenho medido contra as metas do projeto
- [ ] Tokens do design system vigente e temas previstos pelo projeto
- [ ] Layout adaptativo compacto/médio/expandido
- [ ] Estados vazio, carregando, erro e sucesso desenhados
- [ ] Procedimento de corte de `minimalismo-essencial` executado; lista de cortes entregue; microcopy curta, com verbo, pt-BR
- [ ] Acessível (contraste, teclado, foco não encoberto, alvos conforme design system/plataforma)
- [ ] Telas de gestão/cadastro conforme `master-detail-ux` (listagem + detalhe, estado, próximo passo, ação primária única)
- [ ] Tabelas conforme `tabelas-interativas`

===== FIM skills/ux-essencial/SKILL.md =====


===== INÍCIO skills/minimalismo-essencial/SKILL.md =====
---
name: minimalismo-essencial
description: Simplifique interfaces, fluxos e artefatos de produto preservando a tarefa, segurança, acessibilidade e regras de negócio. Use ao criar ou revisar telas e quando pedirem reduzir cliques, campos, etapas, código ou documentação.
---

# Só o que ajuda a tarefa

Cada elemento deve ajudar o usuário a agir, entender, decidir ou recuperar-se de erro, ou ser necessário ao funcionamento e aos controles do processo. Menos elementos não prova melhor usabilidade: medir conclusão, tempo, erro e esforço.

## Teste de essencialidade

1. Qual tarefa, pessoa ou controle depende deste elemento?
2. Ele acrescenta informação ou ação que não existe em outro lugar?
3. É possível reutilizar contexto confiável ou calcular, mantendo visibilidade, correção e aprovação exigida?
4. Se sair da tela, a pessoa ainda encontra e executa a tarefa com clareza e acessibilidade?
5. Há evidência suficiente sobre seu uso, considerando persona, permissão, oportunidade, safra e sazonalidade?

Classifique como **essencial**, **sob demanda** ou **ruído**. Baixa frequência isolada não justifica remover cancelamento, recuperação, auditoria, acessibilidade nem tarefas sazonais. Sem exposição/oportunidade de uso, a métrica não mede desinteresse.

## Direção visual

- Uma ação primária; secundárias úteis junto de seu contexto, sem competição.
- Título curto e linguagem do usuário; ajuda curta quando evita erro ou dúvida real. Não impor zero explicações a pessoas que precisam de orientação.
- Campos necessários ao processo, com rótulo visível e unidade acessível. Não esconder campo obrigatório só para cumprir uma quota.
- Colunas para localizar, comparar e decidir; dados complementares no detalhe. Indicadores apenas quando sustentam uma decisão.
- Eliminar decoração, duplicações, cards sem agrupamento útil, mensagens repetidas e ações sem cenário real.
- Preservar estado, próximo passo e retorno do `master-detail-ux`; atalhos não substituem controles acessíveis no celular.

## Metas de concisão e exceções

Uma ação primária é regra. Como metas iniciais, buscar até duas secundárias visíveis, título de até quatro palavras, criação com até cinco campos, listagem com até seis colunas e painel com até quatro indicadores. São sinais para revisar, não limites que autorizam esconder informação necessária ou quebrar uma tarefa em etapas. Exceder quando o processo, a persona, a acessibilidade ou o design system justificar; explicar brevemente na revisão existente.

Microcopy: verbo + objeto nos botões; erro = o que houve + como corrigir, preferindo até duas frases; vazio = uma frase e uma ação; unidade junto do campo. Evitar exclamações, emojis, jargão e palavras de cortesia repetidas nos controles. Não abreviar a ponto de perder sentido.

Ficam fora por padrão: boas-vindas decorativas, cards só para enquadrar, descrições que repetem o título, ícones sem função, várias ações equivalentes e confirmação repetida sem mudança de risco. Exceções legítimas incluem obrigação vigente, consequência grave ou irreversível, convenção do setor, acessibilidade e identificação de ambiente/sessão.

## Três saídas

1. **Automatizar** cálculos ou preenchimento confiável, com resultado visível/revisável. Rascunho automático não confirma operação de negócio; IA respeita aprovação específica.
2. **Mover para sob demanda** quando a ação é útil mas secundária, mantendo descoberta e acesso compatíveis com a persona.
3. **Remover** ruído comprovado, preservando requisitos, rastreabilidade, integridade e recuperação.

Mudanças funcionais seguem o ciclo de revisão e homologação do projeto. Registrar decisão na tarefa/PRD/rodada existente; não criar um documento paralelo só para listar cortes.

## Aplicar além da tela

PRD mantém resultado, regras, estados, exceções, permissões e aceite observável. Código usa a menor solução clara, sem abstrações para necessidades hipotéticas. Fluxograma mostra decisões que mudam a jornada; subprocessos repetidos viram referências. Testes protegem comportamentos, sem redundância artificial. Fonte única por regra.

## Procedimento final

Inventarie o que importa ao fluxo, classifique e execute os cortes com justificativa. Tente cortar mais um elemento; mantenha-o se passar no teste de essencialidade. Só reintroduza ruído removido com evidência de necessidade. Verifique que a tarefa continua completa, acessível e segura; reverifique o comportamento afetado. Entregue três listas curtas: **aplicado**, **deixado de fora**, **cortado**, com motivo.

Não cortar por estética: aprovações exigidas, isolamento/permissões, unidades, incerteza relevante, distinção entre rascunho/pendente/aceito, contexto de ambiente, avisos necessários ou caminhos de recuperação.

===== FIM skills/minimalismo-essencial/SKILL.md =====


===== INÍCIO skills/tabelas-interativas/SKILL.md =====
---
name: tabelas-interativas
description: Crie e revise tabelas de gestão com filtro e ordenação no cabeçalho, agrupamento por coluna e drill-down. Use em listagens, relatórios web e planilhas; adapte aos recursos do formato e à semântica dos dados.
---

# Tabelas interativas

Toda tabela de dados entregue tem **quatro recursos obrigatórios**. Não são opcionais e não dependem do usuário pedir.

## 1. Ordenação no cabeçalho
- Clicar no título da coluna ordena: crescente → decrescente → sem ordenação.
- Shift+clique adiciona ordenação secundária (mostra ▲1 ▼2).
- Indicador sempre visível (⇅ neutro, ▲/▼ destacado quando ativo). `aria-sort` no `<th>`.
- Vazios sempre no fim, independente da direção. Ordenação numérica/data por valor real, texto com collator `pt-BR` (acentos e números naturais).

## 2. Filtro no cabeçalho
- O campo de filtro fica **dentro da mesma célula `<th>`**, logo abaixo do título — nada de linha extra de filtros, painel lateral ou modal.
- Sintaxe (dica no `title`/placeholder):
  - texto: contém (sem acento/caixa) · `=exato` · `!não contém` · `a|b` (ou) · `∅` vazios
  - números e datas: `>1000`, `<=50`, `!=0`, `10..50`, `>=01/01/2025`, `01/01/2025..31/03/2025`
- Menu ▾ da coluna: ordenar ↑/↓, agrupar por esta coluna, **lista de valores com checkbox e contagem** (estilo Excel, com busca) e "limpar filtro desta coluna".
- Coluna filtrada fica visualmente destacada. Contador "X de Y linhas" sempre visível.

## 3. Agrupamento fácil e rápido por qualquer coluna
- Agrupar por qualquer coluna com ação simples no cabeçalho; oferecer acesso por teclado e toque. Arraste e seletor são alternativas quando úteis, não três controles obrigatórios para a mesma tarefa.
- Multinível (Região › UF › Vendedor), chips removíveis (×) e reordenáveis por arraste.
- Datas agrupam por **ano / mês / dia**.
- Linha de grupo mostra rótulo, contagem e agregados pertinentes, alinhados. Somar apenas grandezas com unidades compatíveis. Percentuais, doses, preços e produtividade usam fórmula do domínio (frequentemente razão de totais/média ponderada), nunca média simples por padrão. Totais devem declarar se abrangem o conjunto filtrado ou só a página carregada.
- Grupos ordenam pela coluna ordenada (se for a do grupo ou uma coluna agregada, ex.: regiões por maior valor).
- Botões "Expandir tudo / Recolher tudo".

## 4. Drill-down assertivo e intuitivo
- **Clique no grupo** → expande/recolhe (▶ gira).
- **"Detalhar ›" ou duplo clique no grupo** → entra no grupo: vira filtro, aparece trilha **"Todos › Região: Sul › UF: RS"** e o próximo nível de agrupamento assume. "← Voltar" e cada migalha restauram o estado anterior (inclusive grupos que estavam abertos).
- **Clique na linha** → painel lateral de detalhe com **todos** os campos (inclusive colunas ocultas), posição "12 de 142", navegação ↑/↓ e botão **"Filtrar por este"** em cada valor (entra direto no drill por aquele valor).
- Teclado: ↑/↓ entre linhas, → / ← abre/fecha grupo, Enter abre, Shift+Enter detalha, Esc fecha.
- Nunca perder o contexto: filtros, ordenação e trilha continuam visíveis; estado vazio mostra "Nenhuma linha corresponde aos filtros · Limpar filtros".

---

## Tabela editável

- Edição na linha ou no painel lateral da linha, conforme o projeto; campos relacionados formam uma operação contínua, com rascunho e erros junto do campo/item, sem confirmações por célula.
- Atualizar totais dependentes sem reordenar linhas, retirar foco ou mover o que a pessoa está digitando. Ordenação/filtro durante edição preserva o rascunho e deixa claro onde ele permanece.
- Em lote com sucesso parcial permitido, mostrar quais itens concluíram, falharam ou aguardam; repetir somente os pendentes com idempotência. Itens interdependentes não podem ficar parcialmente confirmados.
- Fluxo, ação primária e retorno seguem `master-detail-ux`; preenchimento e estados visuais seguem `ux-essencial`.

## Como implementar

### HTML, artifact, relatório web (padrão)
O componente [assets/tabela.js](assets/tabela.js) e [assets/exemplo.html](assets/exemplo.html) são referências a inspecionar e testar; não presumir conformidade, segurança ou agregação correta. Prefira o componente existente do projeto quando ele atende ao contrato. Para grandes bases, filtro/ordenação/agrupamento devem operar no conjunto autorizado no servidor, sem fingir totais globais sobre uma página local.

1. Leia `assets/tabela.js` e **cole o conteúdo inteiro em um `<script>` inline** (artifacts bloqueiam scripts de hosts não permitidos; em projetos com build, copie o arquivo para o repositório).
2. Crie a tabela:

```html
<div id="vendas"></div>
<script>/* conteúdo de tabela.js */</script>
<script>
  Tabela.create('#vendas', {
    rows: dados,                       // array de objetos
    columns: [
      { key: 'pedido', label: 'Pedido', type: 'text' },
      { key: 'data', label: 'Data', type: 'date' },          // 'AAAA-MM-DD', dd/mm/aaaa ou Date
      { key: 'regiao', label: 'Região' },
      { key: 'valor', label: 'Valor', type: 'currency' },   // agg padrão: sum
      { key: 'margem', label: 'Margem', type: 'percent' },  // 0.23 → 23,0%; agg padrão: avg
      { key: 'obs', label: 'Observação', hidden: true },     // só no painel de detalhe
    ],
    groupBy: ['regiao'],        // agrupamento inicial opcional; datas: 'data:ano' | 'data:mes' | 'data:dia'
    sort: ['-valor'],           // '-' = decrescente
    expandLevels: 0,            // quantos níveis abrir de início
    rowTitle: (r) => `Pedido ${r.pedido}`,   // título do painel de detalhe
    detail: (r) => '',          // HTML extra no painel (gráfico, links) — opcional
  });
</script>
```

Opções de coluna: `key`, `label`, `type` (`text` | `integer` | `number` | `currency` | `percent` | `date`), `agg` (`sum` | `avg` | `min` | `max` | `count` | função `(rows)=>valor` | `null`), `decimals`, `currency` (padrão `BRL`), `format(v,row)`, `render(v,row)` (retorna HTML — escape você mesmo), `value(row)` (coluna calculada), `width`, `hidden`.

Defina tipos explicitamente: ID, CPF, CEP e nº de pedido são códigos, não medidas. Use `agg: null` quando não houver agregado válido; preços/percentuais exigem regra explícita e denominador conhecido, sobrescrevendo qualquer média automática do exemplo.

API retornada: `setRows(rows)`, `groupBy([...])`, `filter(key, texto)`, `sort(key, 1|-1|0)`, `drillTo([{spec, key, label}])`, `clearFilters()`, `getRows()`, `getState()`, `destroy()`.

Várias tabelas na mesma página: chame `Tabela.create` para cada container. Altura máxima com rolagem e cabeçalho fixo: opção `maxHeight` (padrão `70vh`).

### React / Next / Vue
Envolva o mesmo componente — o comportamento fica idêntico:

```jsx
function TabelaInterativa({ rows, columns, ...opts }) {
  const ref = useRef(null), api = useRef(null);
  useEffect(() => { api.current = Tabela.create(ref.current, { rows, columns, ...opts }); return () => api.current.destroy(); }, [columns]);
  useEffect(() => { api.current?.setRows(rows); }, [rows]);
  return <div ref={ref} />;
}
```
Se o projeto já usa TanStack Table/AG Grid/MUI DataGrid, pode usar a biblioteca, mas **cumpra o checklist abaixo item por item** (atenção: agrupamento no AG Grid e MUI é recurso pago — nesse caso, use `tabela.js`).

### Streamlit / Dash / Jupyter
Renderize o HTML com `tabela.js` inline: `st.components.v1.html(html, height=700, scrolling=True)`; em Dash, `html.Iframe(srcDoc=html)`; no Jupyter, `IPython.display.HTML`. Serialize os dados com `df.to_json(orient='records', date_format='iso')`.

### Excel (.xlsx)
Planilha não tem drill-down igual ao da web, então reproduza o equivalente nativo:
- Dados como **Tabela do Excel** (`openpyxl.worksheet.table.Table`) → botões de filtro/ordenação na linha de cabeçalho; `freeze_panes` abaixo do cabeçalho; formatos numéricos corretos.
- Aba **"Resumo"** agrupada pela dimensão principal (e subníveis) com `SUBTOTAL`/`SUMIFS` e **estrutura de tópicos** (`row_dimensions.group(..., outline_level=n)`) para expandir/recolher.
- Drill-down: cada linha do resumo com **hiperlink** para a aba de dados (ou aba de detalhe por grupo).
- Se o usuário usa Excel desktop, sugerir também uma Tabela Dinâmica sobre a Tabela.

### Terminal / chat em Markdown
Markdown não é interativo. Para tabelas pequenas (até ~15 linhas) mostre normalmente. Para dados maiores, ou quando o usuário for explorar, **gere a versão interativa** (artifact/HTML com `tabela.js`) e dê o link.

---

## Checklist antes de entregar qualquer tabela
- [ ] Clique no cabeçalho ordena; Shift+clique ordena por várias colunas; indicador visível
- [ ] Campo de filtro dentro do `<th>` de cada coluna, com operadores para números/datas
- [ ] Menu ▾ com lista de valores (checkbox + contagem + busca)
- [ ] Agrupar por qualquer coluna em 1 gesto (arrastar, menu ou seletor), multinível, datas por ano/mês/dia
- [ ] Linhas de grupo com contagem e agregados alinhados; total no rodapé
- [ ] Drill-down: expandir grupo, "Detalhar" com trilha e Voltar, painel de detalhe da linha com "Filtrar por este"
- [ ] Contador "X de Y linhas", filtros ativos destacados, estado vazio com "Limpar filtros"
- [ ] Tipos corretos (códigos como texto, moeda BRL, percentuais, datas pt-BR)
- [ ] Funciona com teclado e nos temas claro e escuro

===== FIM skills/tabelas-interativas/SKILL.md =====


===== INÍCIO skills/dev-frontend-mobile/SKILL.md =====
---
name: dev-frontend-mobile
description: Implemente e revise interfaces web, PWA e mobile com estado, formulários, desempenho, acessibilidade, offline e sincronização confiáveis. Use ao alterar telas, componentes ou navegação executável.
---

# Frontend e mobile — meta: rápido, robusto, sem bug de tela

UX/UI é `ux-essencial`; organização das telas (listagem → detalhe → sub-detalhe, rotas `/entidade`, `/entidade/:id`) é `master-detail-ux`; tabelas é `tabelas-interativas`. Aqui é a engenharia por trás.

## Estrutura e código
- **Organização por feature**, não por tipo: `src/features/pedidos/{components,hooks,api,schemas,index.ts}`; `src/shared/{ui,lib,hooks}` só para o que é realmente genérico. Feature exporta só pelo `index.ts`; sem import cruzado entre features (usar `shared` ou compor na página).
- **TypeScript estrito** (`dev-revisao/assets/tsconfig.strict.json`); props tipadas; sem `any`; discriminated unions para estados (`{status:'loading'} | {status:'error', error} | {status:'ok', data}`), nunca vários booleanos.
- **Componentes coesos**, uma responsabilidade; lógica em funções testáveis. Não fragmentar só por contagem de linhas. Regra compartilhada de domínio não substitui validação autoritativa no servidor.
- **Design system** único: o design system do projeto prevalece; usar seus tokens e componentes em `shared/ui`, sem hex/px solto. M3 de `ux-essencial` vale somente na ausência de padrão. Storybook quando o projeto adotar, sem introduzi-lo por obrigação em toda mudança.
- Sem duplicação: verificar `shared/ui` antes de criar componente; variantes via props, não cópia.

## Estado (três tipos, três ferramentas)
| Tipo | Ferramenta | Regra |
|---|---|---|
| **Servidor** (dados da API) | TanStack Query / SWR / RTK Query; Server Components + Server Actions no Next | cache, revalidação, retry, **atualização otimista**; nunca copiar para estado global |
| **Cliente** (UI: modal aberto, rascunho) | `useState` local → Zustand/signals/Riverpod/ViewModel só se compartilhado | mínimo possível; derivar em vez de duplicar |
| **URL** (filtro, aba, página, item aberto) | router (`searchParams`) | tudo que o usuário quer compartilhar/recarregar/voltar |

Cliente de API **tipado e gerado do OpenAPI** (openapi-typescript/orval); schemas zod compartilhados com o backend quando monorepo.

## Formulários e dados
- Reutilizar a biblioteca do projeto; schema, validação útil, teclado e autocomplete corretos. Autosave preserva rascunho; comandos de negócio exigem envio explícito. Atualização otimista só onde reversível, com pendência visível e sem afirmar aceite antes do recibo.
- Datas: `Intl`/`date-fns` com fuso explícito; números/moeda com `Intl.NumberFormat('pt-BR')`. Nunca `toFixed` para dinheiro.
- Listas > 200 itens virtualizadas (TanStack Virtual / FlashList / `ListView.builder`).

## Rotas, erros e carregamento
- Rotas com **lazy loading** por página; **error boundary** por rota e por widget crítico com ação de tentar de novo; `Suspense` com skeleton no formato do conteúdo.
- Tratamento global: erro de rede → snackbar com "Tentar de novo"; 401 → renovar token/login mantendo a rota de retorno; 403/404 → página própria.
- Erros e Web Vitals enviados ao Sentry (com release e source maps); nunca falhar em silêncio.

## Performance (orçamento medido no CI)
- **Web**: JS inicial ≤ 200 kB gz; LCP < 2,5 s, INP < 200 ms, CLS < 0,1 (Lighthouse CI no pipeline, falha se regredir). Code splitting, `next/image`/`<img width height loading=lazy>`, fontes com `display=swap` e preload, sem biblioteca pesada para coisa pequena (checar bundle com `source-map-explorer`), memoização só onde medido, sem re-render em cascata (React DevTools Profiler / React Compiler).
- **Mobile**: 60 fps em listas (FlashList/RecyclerView/`ListView.builder`), imagens em cache com tamanho certo, sem trabalho pesado na thread de UI, startup < 2 s, Hermes ativado (RN), tamanho do app monitorado.
- Pré-carregar a próxima tela provável; stale-while-revalidate; `prefetch` nos links visíveis.

## Segurança no cliente
- Nada de segredo no bundle (só chaves públicas); chamadas sensíveis passam pelo backend.
- Sem `dangerouslySetInnerHTML`/`innerHTML` com dado do usuário; sanitizar (DOMPurify) se inevitável; **CSP** estrita com nonce; cookies `HttpOnly` para sessão (nada de token em `localStorage`).
- Mobile: token em Keychain/Keystore (`expo-secure-store`); certificate pinning em app financeiro; ofuscação/ProGuard em release; sem log sensível.
- Dependências auditadas; Renovate semanal.

## Acessibilidade (testada, não só pretendida)
- `jest-axe`/`@axe-core/playwright` nos testes; Testing Library consulta por papel/rótulo (força HTML semântico).
- Teclado completo, foco visível e gerido em modais/rotas, `aria-live` para snackbar, contraste AA, `prefers-reduced-motion`.
- Mobile: TalkBack/VoiceOver nos fluxos principais; alvos conforme o design system e a plataforma; na ausência, ≥ 48 dp; `accessibilityLabel` em ícones.

## Mobile — específico
- **PWA em campo**: IndexedDB para rascunhos/fila e Service Worker para recursos offline, conforme a arquitetura do projeto. Testar limites de armazenamento, expulsão de cache e encerramento do navegador. Não depender exclusivamente de sincronização em segundo plano: oferecer recuperação/reenvio em primeiro plano com recibo e idempotência. Conferir suporte atual em iOS/Android nos dispositivos-alvo antes de prometer operação offline; isso não exige criar app nativo.
- **Expo (RN)** por padrão (EAS Build/Submit/Update, expo-router, TypeScript); **Flutter** quando o time é Dart ou precisa de UI pixel-idêntica; nativo (Compose/SwiftUI) por exigência de plataforma (widgets, watch, hardware).
- Arquitetura: feature-first; MVVM/ViewModel (Compose, SwiftUI) ou hooks + Query (RN); Riverpod/Bloc (Flutter).
- **Offline-first** no campo: armazenamento local por empresa/usuário, fila persistente, idempotência e política de conflito. Distinguir salvo localmente, pendente, rejeitado e aceito conforme vocabulário do projeto; aceite requer recibo do servidor. Testar reinício, perda de rede, reenvio, troca de conta e conflito sem duplicar estoque/custos. Limpar/proteger dados no logout conforme política.
- Deep links / universal links configurados; push (FCM/APNs) com opt-in no momento certo; permissões pedidas just-in-time com explicação.
- Crash reporting (Sentry/Crashlytics), analytics de eventos-chave, feature flags remotas, **OTA updates** (EAS Update) para JS; versionamento semântico + build number automático.
- CI: lint + testes + build de release em todo PR; distribuição interna (TestFlight/Internal testing) automática do trunk; checklist de loja (ícones, splash, capturas, privacidade, política, `NSUsageDescription`, permissões mínimas).
- Testes: unit (lógica), componente (RNTL/widget tests/Compose tests), E2E (Maestro) nos 5–10 fluxos críticos em iOS **e** Android; golden/snapshot para componentes de design system.

## Checklist de tela/componente
- [ ] Feature coesa e lógica testável; sem fragmentação artificial
- [ ] Estado no lugar certo; otimista apenas onde seguro; local/pendente/aceito distintos
- [ ] Estados vazio/carregando/erro/sucesso implementados; error boundary; skeleton
- [ ] Formulário com schema, validação, rascunho e envio explícito quando necessário; teclado/autocomplete corretos
- [ ] Tipos estritos; cliente de API gerado; sem `any`
- [ ] Lighthouse/Web Vitals ou fps dentro do orçamento; bundle não cresceu
- [ ] Acessibilidade com axe passando; teclado/leitor de tela
- [ ] Testes: unit + componente (Testing Library) + E2E se fluxo crítico
- [ ] Claro/escuro, responsivo (compacto/médio/expandido), pt-BR

===== FIM skills/dev-frontend-mobile/SKILL.md =====


===== INÍCIO skills/dev-testes/SKILL.md =====
---
name: dev-testes
description: Defina e execute testes proporcionais ao comportamento e risco, incluindo unitários, integração, contrato, E2E e carga quando pertinente. Use em implementação, regressões, diagnóstico de testes e critérios de liberação.
---

# Testes automatizados — reduzir falhas com evidência

Teste comportamentos e riscos, não contagens. Nenhuma suíte garante ausência absoluta de bugs. Ajustes de texto/instruções ou visuais reversíveis sem mudança de comportamento podem ser verificados por leitura/inspeção; não criar testes que só repetem a implementação.

## TDD por padrão
1. **Vermelho:** escrever o menor teste que descreve o comportamento desejado e vê-lo falhar (pelo motivo certo).
2. **Verde:** o código mais simples que passa.
3. **Refatorar:** limpar duplicação e nomes com a suíte verde.
Bug reportado → reproduzir e escrever a regressão quando viável → corrigir → verificar. Execute os testes afetados a cada mudança; amplie para a suíte exigida no gate de entrega, sem repetir baterias intactas sem motivo.

## Pirâmide (referência, não quota)
| Nível | O que cobre | Velocidade | Quanto |
|---|---|---|---|
| **Unitário** | regras de negócio, cálculos, validações, reducers, utils, componentes isolados | ms | 70 % |
| **Integração** | módulo + banco real (Testcontainers/Docker), handlers HTTP, filas, repositórios, componentes com dados | ~100 ms–1 s | 20 % |
| **Contrato** | forma das APIs entre front/back e serviços (OpenAPI/Pact); schema do banco vs. ORM | rápido | por API |
| **E2E** | 5–15 fluxos críticos completos no navegador/dispositivo (login, cadastro, compra, fluxo principal) | s | 10 % |
| **Propriedade** | invariantes com dados gerados (fast-check / Hypothesis) para parsers, cálculos, serialização | — | onde há lógica densa |
| **Mutação** | Stryker / mutmut no núcleo de domínio: prova que os testes detectam mudanças | lento, CI noturno | domínio |
| **Carga** | k6 nos endpoints críticos antes de lançar e antes de picos | — | pré-lançamento |

Mocks só na fronteira do sistema (APIs de terceiros, relógio, aleatoriedade, e-mail). **Banco de dados é real** nos testes de integração (Docker), nunca mockado.

## O que obrigatoriamente testar
- Caminho feliz, **limites** (0, 1, máximo, vazio, nulo, unicode, negativo), **erros** (entrada inválida, rede falha, timeout, concorrência).
- Dinheiro, arredondamento, datas/timezones/horário de verão, ordenação com acentos.
- **Permissões**: cada endpoint com usuário sem permissão → 403; sem login → 401; outro tenant → 404.
- Idempotência de operações repetidas e concorrentes; migrações com dados, compatibilidade e recuperação. Um rollback de código não exige nem autoriza apagar dados com uma migração reversa.
- Estados de UI: vazio, carregando, erro, sucesso; acessibilidade (axe) nos componentes.

## Como escrever testes bons
- **Nome descreve comportamento**: `deve rejeitar pedido com quantidade zero` / `test_rejects_zero_quantity`. Um comportamento por teste.
- Estrutura **Arrange–Act–Assert**, sem lógica (if/loop) dentro do teste.
- **Determinístico**: relógio falso, seed fixa, sem `sleep`, sem depender de ordem ou de rede; cada teste cria e limpa seus dados (transação com rollback ou banco por teste).
- Dados via **factories/builders** (`buildPedido({ total: 0 })`), não fixtures gigantes.
- Asserções específicas (`toEqual({...})`, não `toBeTruthy`); mensagens de erro verificadas por conteúdo.
- Testar comportamento observável, não implementação (não asserta chamadas internas nem estado privado).
- Testes de componente com Testing Library: consultar por papel/rótulo acessível (`getByRole('button', { name: 'Salvar' })`), nunca por classe/CSS.
- Metas de duração definidas pelo projeto e medidas. Paralelismo/sharding só com isolamento de dados, portas e perfis; jornadas dependentes declaram sequência e precondições. Scripts agregadores falham quando uma verificação falha; ajuda, zero testes e testes pulados não contam como aprovação.

## Cobertura e confiança
- Preserve os gates já contratados pelo projeto. Em projeto novo, defina metas pelo risco e pela linha de base, sem impor percentuais arbitrários como prova de qualidade.
- Domínio, dinheiro, permissões, concorrência e sincronização exigem cenários felizes, negativos e limites pertinentes. Remover código morto pode mudar a cobertura; avalie a proteção do comportamento, não apenas o percentual. Mutação é útil quando revela lacunas do núcleo, não em toda mudança.

## Testes instáveis (flaky)
Registre causa, responsável e prazo pela criticidade. Não coloque em quarentena a única prova de uma regra crítica para liberar a entrega. Repetições diagnósticas ficam explícitas; testes instáveis não viram aprovação por retry silencioso.

## Ferramentas por stack
| Stack | Unit/Integração | Componentes | E2E | Extras |
|---|---|---|---|---|
| TypeScript/Node/React | **Vitest** (ou Jest) + Testcontainers/`pg-mem` não; usar Postgres real | Testing Library + jest-axe; Storybook + test-runner | **Playwright** (traços, vídeos, sharding) | fast-check, Stryker, MSW (mock de HTTP), k6, `supertest` |
| Python | **pytest** + pytest-asyncio + Testcontainers; `httpx.AsyncClient` para FastAPI | — | Playwright (Python) | Hypothesis, mutmut, factory_boy, freezegun, respx |
| Go | `testing` + testify + Testcontainers | — | Playwright | rapid (property), gomock só na borda |
| Android/Kotlin | JUnit5 + MockK + Turbine | Compose UI tests | Maestro / Espresso | Kotest property |
| iOS/Swift | XCTest / Swift Testing | ViewInspector / snapshot | XCUITest / Maestro | — |
| React Native/Expo | Vitest/Jest + RNTL | RNTL | **Maestro** ou Detox | — |
| Flutter | `flutter test` | widget tests | `integration_test` / Maestro / Patrol | golden tests |

Configurações prontas: [assets/vitest.config.ts](assets/vitest.config.ts), [assets/playwright.config.ts](assets/playwright.config.ts), [assets/pytest.ini](assets/pytest.ini).

## Checklist do PR
- [ ] Comportamentos e riscos alterados têm testes no nível adequado; fronteiras críticas têm integração e jornadas críticas têm E2E
- [ ] Bug corrigido tem teste que falhava antes
- [ ] Nenhum `skip`/`only`/`xit`; nenhum teste com `sleep` ou dependência de ordem
- [ ] Limites, erros e permissões cobertos
- [ ] Gates de cobertura pertinentes atendidos; duração medida; nenhum agregado mascara falha ou ausência de testes
- [ ] Testes legíveis: alguém entende o comportamento só lendo os nomes

===== FIM skills/dev-testes/SKILL.md =====
