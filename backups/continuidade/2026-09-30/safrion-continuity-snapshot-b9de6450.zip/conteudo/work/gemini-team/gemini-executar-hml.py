"""Reusa o transporte Gemini revisado; ferramenta fixa para HML-A1-02/A5, sem comandos do modelo."""
import importlib.util
import json
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
spec = importlib.util.spec_from_file_location('transporte_gemini', HERE / 'gemini-executar-testes.py')
transport = importlib.util.module_from_spec(spec)
spec.loader.exec_module(transport)
transport.BASE = '296a1905cb0cf46dc20d3e4cb099a178febbecdc'
transport.CANDIDATE = '2b939c35c943036d29b9ec97d0ac38bf94addab1'
transport.SNAPSHOT = Path('/private/tmp/safrion-hml-a1-02-aa66b1e')
transport.MANIFEST = HERE / 'executor-hml-manifest.json'
transport.TOOL = 'executar_verificacao_hml_a1_a5'
transport.DECLARATION = {
    'name': transport.TOOL,
    'description': 'Executa uma vez 3 provas HML-A1-02 e16 controles A5 em PostgreSQL local descartável; sem infraestrutura externa.',
    'parameters': {'type': 'OBJECT', 'properties': {'candidata': {'type': 'STRING', 'enum': [transport.CANDIDATE]}}, 'required': ['candidata']},
}
transport.SYSTEM = (
    'Você é Gemini real na equipe Safrion. Use somente a ferramenta declarada para acionar19cenários reais em PG local descartável. '
    'Não há acesso livre a shell, nuvem, IAM, produção ou dados reais. Registre solicitante modelo/executor local, versão e limites. '
    'Falha ou ausência de resultado não é aprovação. Esta rodada não libera HML web nem produção. Responda em português de forma breve.'
)
transport.PROMPT = (
    'Acione executar_verificacao_hml_a1_a5 para candidata2b939c35c943036d29b9ec97d0ac38bf94addab1. '
    'Claude implementou HML-A1-02 e executou76unitários/61integrações; Codex retestou esses e6provas independentes. '
    'Você já leu papeis.ts blob b4c005b, mas alegou erroneamente42883 em pg_advisory_lock(hashtext(...)). '
    'Os testes reais passam; uma prova explícita consulta pg_cast(integer,bigint) e executa lock/unlock sem cast. '
    'Revise sua conclusão conforme esse resultado, não repita uma afirmação contrariada pelo banco. Cause não enumerável protege JSON padrão, não qualquer logger. '
    'Agora Claude apontou três lacunas na consulta A5 de Codex: membro de migrator pode desabilitar RLS; '
    'pg_write_all_data escreve sem grant específico; CREATE no banco cria schemas. Codex reproduziu antes, corrigiu conforme proposta do Claude '
    'e retestou16controles. A política conservadora exige nenhum papel atribuído a app_runtime e nenhum CREATE no banco. '
    'Ainda não é auditoria de todo GRANT/ownership e falta prova Cloud SQL real. '
    'A ferramenta executa as3provas de falhas A1 (42501+queda no rollback, commit real com resposta perdida, desbloqueio falho com conexão viva) '
    'e16controles A5, incluindo contraexemplos/controles positivos/negativos e prova do cast. Use-a e avalie a evidência. '
    'Consulta A5 corrigida, para revisão delimitada:\n' + (ROOT / 'work/hml-review/consultar-papel-runtime.sql').read_text()
)

EXPECTED = {
    'limpeza': {
        'erro_42501_preservado_apos_queda_no_rollback',
        'commit_efetivado_com_resposta_perdida_nao_gera_falso_sucesso',
        'falha_desbloqueio_vivo_exige_encerrar_conexao_e_libera_trava',
    },
    'a5': {
        'primeiro_provisionamento_limitado', 'catalogo_cloud_sql_ausente', 'runtime_restrito',
        'runtime_SUPERUSER', 'runtime_BYPASSRLS', 'runtime_CREATEROLE', 'runtime_CREATEDB', 'runtime_REPLICATION',
        'consulta_antiga_aprova_excesso', 'associacao_indireta_cloudsqlsuperuser', 'filiacao_sem_heranca_nem_set_role',
        'administrador_disfarcado_por_set_role', 'membro_migrator_pode_desabilitar_rls',
        'membro_pg_write_all_data_escreve_sem_grant_especifico', 'create_no_banco_permite_criar_schema',
        'integer_bigint_implicito_e_advisory_lock_real',
    },
}

def execute_tests(run_dir):
    manifest_sha = transport.verify_manifest()
    cfg = json.loads((HERE / 'executor-runtime.json').read_text())
    pg = Path(cfg['pg'])
    cluster = Path('/private/tmp/safrion-gemini-hml-' + run_dir.name)
    cluster.mkdir(mode=0o700)
    pw = cluster / 'password'
    pw.write_text(secrets.token_urlsafe(30))
    pw.chmod(0o600)
    env = {key: os.environ[key] for key in ('PATH', 'TMPDIR') if key in os.environ}
    env.update(REVIEW_PG_SOCKET=str(cluster), REVIEW_PG_PASSWORD=pw.read_text(), LANG='en_US.UTF-8')
    for name in ('retestar-limpeza-b4c005b.mjs', 'retestar-a5.mjs', 'consultar-papel-runtime.sql', 'consultar-papel-runtime-antes-a5-revisao.sql'):
        shutil.copyfile(ROOT / 'work/hml-review' / name, run_dir / name)
    steps = []
    passed = False
    tests = []
    def run(name, command, timeout=120):
        result = subprocess.run(command, cwd=run_dir, env=env, capture_output=True, text=True, timeout=timeout)
        steps.append({'step': name, 'exit': result.returncode})
        if result.returncode:
            raise RuntimeError('STEP_FAILED')
    try:
        run('initdb', [str(pg / 'initdb'), '-D', str(cluster / 'data'), '-U', 'review_root', '-A', 'scram-sha-256', '--pwfile', str(pw), '--encoding=UTF8'])
        run('start', [str(pg / 'pg_ctl'), '-D', str(cluster / 'data'), '-l', str(cluster / 'postgres.log'), '-o', "-h '' -p56301 -k " + str(cluster), '-w', 'start'])
        run('limpeza', [cfg['node'], str(run_dir / 'retestar-limpeza-b4c005b.mjs')])
        run('a5', [cfg['node'], str(run_dir / 'retestar-a5.mjs'), 'depois'])
        for group, filename in (('limpeza', 'resultado-hml-a1-02-b4c005b-limpeza.json'), ('a5', 'resultado-a5-depois.json')):
            result = json.loads((run_dir / filename).read_text())
            cases = result['casos']
            if not result['completed'] or result['cleanup'] != 'ok' or len(cases) != len(EXPECTED[group]) or {c['caso'] for c in cases} != EXPECTED[group]:
                raise ValueError('INCOMPLETE_REPORT')
            for case in cases:
                if case['resultado'] not in ('passou', 'recusado', 'aceito_no_escopo', 'recusado_conservadoramente', 'falso_verde_reproduzido'):
                    raise ValueError('UNKNOWN_RESULT')
                tests.append({'group': group, 'test': case['caso'], 'result': case['resultado']})
        passed = True
    except (ValueError, KeyError, RuntimeError, OSError, subprocess.SubprocessError):
        passed = False
    finally:
        try:
            if (cluster / 'data/postmaster.pid').exists():
                run('stop', [str(pg / 'pg_ctl'), '-D', str(cluster / 'data'), '-m', 'fast', '-w', 'stop'], 30)
        except (RuntimeError, OSError, subprocess.SubprocessError):
            passed = False
        finally:
            pw.unlink(missing_ok=True)
    stopped = not (cluster / 'data/postmaster.pid').exists()
    transport.verify_manifest()
    return {'status': 'executed' if len(tests) == 19 else 'incomplete', 'candidate': transport.CANDIDATE,
            'scenarios_passed': passed and stopped, 'tests': tests, 'steps': steps,
            'cluster_stopped': stopped, 'password_removed': not pw.exists(), 'manifest_sha256': manifest_sha,
            'scope': 'PG local descartável, sem Cloud SQL real, web, HML hospedada ou produção'}

transport.execute_tests = execute_tests
if __name__ == '__main__':
    sys.exit(transport.main())
