"""Offline: proteção contra execução arbitrária, falso verde e vazamento em relatórios."""
import copy
import importlib.util
import json
import os
import shutil
import subprocess
import uuid
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, patch

spec = importlib.util.spec_from_file_location('executor', Path(__file__).with_name('gemini-executar-testes.py'))
e = importlib.util.module_from_spec(spec)
spec.loader.exec_module(e)


def report():
    return {'success': True, 'testResults': [{'assertionResults': [
        {'fullName': name, 'status': 'passed', 'failureMessages': ['SECRET_CANARY'], 'extra': 'SECRET_CANARY'}
        for name in e.TESTS]}]}


class Results(unittest.TestCase):
    def test_pass_requires_complete_suite_zero_exit_and_cleanup(self):
        r = report()
        self.assertTrue(e.safe_results(r, 0, True)['scenarios_passed'])
        for result in (e.safe_results(r, 1, True), e.safe_results(r, 0, False), e.safe_results({'success': False, 'testResults': r['testResults']}, 0, True)):
            self.assertFalse(result['scenarios_passed'])

    def test_missing_duplicate_skipped_and_failed_cannot_approve(self):
        for mutation in ('missing', 'duplicate', 'skipped', 'failed'):
            r = report(); tests = r['testResults'][0]['assertionResults']
            if mutation == 'missing': tests.pop()
            elif mutation == 'duplicate': tests[-1] = copy.deepcopy(tests[0])
            else: tests[0]['status'] = mutation
            self.assertFalse(e.safe_results(r, 0, True)['scenarios_passed'])

    def test_raw_driver_messages_and_unknown_names_are_not_forwarded(self):
        self.assertNotIn('SECRET_CANARY', json.dumps(e.safe_results(report(), 0, True)))
        r = report(); r['testResults'][0]['assertionResults'][0]['fullName'] = 'SECRET_CANARY'
        result = e.safe_results(r, 0, True)
        self.assertFalse(result['scenarios_passed'])
        self.assertNotIn('SECRET_CANARY', json.dumps(result))

    def test_model_cannot_choose_shell_path_other_candidate_or_extra_argument(self):
        valid = {'name': e.TOOL, 'args': {'candidata': e.CANDIDATE}}
        e.validate_call(valid)
        for invalid in (None, {'name': 'exec', 'args': {'command': 'touch /tmp/no'}},
                        {'name': e.TOOL, 'args': {'candidata': '../other'}},
                        {'name': e.TOOL, 'args': {'candidata': e.CANDIDATE, 'command': 'secret'}}):
            with self.assertRaises(ValueError): e.validate_call(invalid)


class Conversation(unittest.TestCase):
    def run_case(self, first, second=None):
        with tempfile.TemporaryDirectory() as tmp:
            response2 = second or {'candidates': [{'finishReason': 'STOP', 'content': {'role': 'model', 'parts': [{'text': 'Resultado recebido.'}]}}]}
            with patch.object(e, 'HERE', Path(tmp)), patch.object(e, 'verify_manifest', return_value='manifest-hash'), \
                 patch.object(e, 'access_token', return_value='TOKEN_CANARY'), patch.object(e, 'call_model', side_effect=[first, response2]) as api, \
                 patch.object(e, 'execute_tests', return_value={'status': 'executed', 'scenarios_passed': False, 'tests': []}) as run, \
                 patch.object(sys, 'argv', ['executor']), patch('builtins.print'):
                status = e.main()
            evidence = json.loads(next(Path(tmp).glob('runs/*/evidence.json')).read_text())
            self.assertNotIn('TOKEN_CANARY', json.dumps(evidence))
            return status, evidence, api, run

    def test_model_must_request_exactly_one_valid_tool_before_execution(self):
        for parts in ([{'text': 'Aprovado sem executar'}], [{'functionCall': {'name': 'shell', 'args': {}}}],
                      [{'functionCall': {'name': e.TOOL, 'args': {'candidata': e.CANDIDATE}}}] * 2):
            status, record, api, run = self.run_case({'candidates': [{'finishReason': 'STOP', 'content': {'role': 'model', 'parts': parts}}]})
            run.assert_not_called(); self.assertEqual(api.call_count, 1); self.assertEqual(status, 1)
            self.assertFalse(record['execution_complete'])

    def test_truncated_model_call_never_executes(self):
        first = {'candidates': [{'finishReason': 'MAX_TOKENS', 'content': {'role': 'model', 'parts': [
            {'functionCall': {'name': e.TOOL, 'args': {'candidata': e.CANDIDATE}}}]}}]}
        _, _, _, run = self.run_case(first); run.assert_not_called()

    def test_exactly_one_run_two_calls_preserved_signature_and_real_failure(self):
        content = {'role': 'model', 'parts': [{'thoughtSignature': 'SIGNATURE_CANARY', 'functionCall': {
            'name': e.TOOL, 'args': {'candidata': e.CANDIDATE}, 'id': 'req1'}}]}
        status, record, api, run = self.run_case({'candidates': [{'finishReason': 'STOP', 'content': content}]})
        self.assertEqual(run.call_count, 1); self.assertEqual(api.call_count, 2); self.assertEqual(status, 3)
        self.assertFalse(record['scenarios_passed']); self.assertTrue(record['execution_complete'])
        followup = api.call_args_list[1].args[0]
        self.assertEqual(followup['contents'][1], content)
        self.assertEqual(followup['contents'][2]['parts'][0]['functionResponse']['id'], 'req1')
        self.assertFalse(followup['contents'][2]['parts'][0]['functionResponse']['response']['output']['scenarios_passed'])
        self.assertEqual(followup['toolConfig']['functionCallingConfig']['mode'], 'NONE')
        self.assertNotIn('SIGNATURE_CANARY', json.dumps(record))

    def test_malformed_api_shape_is_sanitized(self):
        status, record, _, run = self.run_case({'candidates': [{'finishReason': 'STOP', 'content': None}]})
        self.assertEqual(status, 1); self.assertEqual(record['error'], 'EXECUTION_OR_API_FAILED'); run.assert_not_called()

    def test_missing_final_analysis_is_not_complete(self):
        first = {'candidates': [{'finishReason': 'STOP', 'content': {'parts': [
            {'functionCall': {'name': e.TOOL, 'args': {'candidata': e.CANDIDATE}}}]}}]}
        status, record, _, run = self.run_case(first, {'candidates': [{'finishReason': 'MAX_TOKENS'}]})
        self.assertEqual(run.call_count, 1); self.assertEqual(status, 1); self.assertFalse(record['complete'])


class Manifest(unittest.TestCase):
    def test_changed_source_and_parent_symlink_escape_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); snap = root/'snapshot'; snap.mkdir(); source = snap/'code'; source.write_text('reviewed')
            manifest = root/'manifest.json'
            manifest.write_text(json.dumps({'candidate': e.CANDIDATE, 'base': e.BASE, 'files': [{'path': str(source), 'sha256': e.sha(source)}]}))
            with patch.object(e, 'MANIFEST', manifest), patch.object(e, 'SNAPSHOT', snap), patch.object(e, 'ROOT', root/'project'):
                self.assertTrue(e.verify_manifest())
                source.write_text('changed')
                with self.assertRaisesRegex(ValueError, 'REVIEWED_FILE_CHANGED'): e.verify_manifest()
                outside = root/'outside'; outside.mkdir(); (outside/'code').write_text('reviewed')
                (snap/'parent').symlink_to(outside, target_is_directory=True)
                manifest.write_text(json.dumps({'candidate': e.CANDIDATE, 'base': e.BASE, 'files': [{'path': str(snap/'parent/code'), 'sha256': e.sha(outside/'code')}]}))
                with self.assertRaisesRegex(ValueError, 'PATH_OUTSIDE_REVIEW'): e.verify_manifest()


class Lifecycle(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name).resolve()
        self.here = self.root/'work/gemini-team'; self.here.mkdir(parents=True)
        self.run_dir = self.here/'runs'/uuid.uuid4().hex; self.run_dir.mkdir(parents=True)
        self.cluster = Path('/private/tmp/safrion-gemini-pg-' + self.run_dir.name)
        self.marker = self.run_dir/'cleanup-called'
        pg = self.root/'pg'; pg.mkdir()
        # Simula somente a ferramenta de parada: não inicia servidor nem usa credenciais.
        script = pg/'pg_ctl'
        script.write_text('#!' + sys.executable + '\nfrom pathlib import Path\nPath(' + repr(str(self.marker)) + ').touch()\nPath(' + repr(str(self.cluster/'data/postmaster.pid')) + ').unlink(missing_ok=True)\n')
        script.chmod(0o700)
        (self.here/'executor-runtime.json').write_text(json.dumps({'pg': str(pg)}))
        self.harness = self.root/'work/run-f0b-review.py'
        self.harness.write_text('')
        self.patches = [patch.object(e, 'ROOT', self.root), patch.object(e, 'HERE', self.here), patch.object(e, 'verify_manifest', return_value='hash')]
        self.manifest = None
        for p in self.patches: self.manifest = p.start()

    def tearDown(self):
        for p in reversed(self.patches): p.stop()
        if self.cluster.exists(): shutil.rmtree(self.cluster)
        self.temp.cleanup()

    def prepare_cluster(self):
        (self.cluster/'data').mkdir(parents=True)
        (self.cluster/'data/postmaster.pid').write_text('fixture only')
        (self.cluster/'password').write_text('synthetic')

    def test_timeout_real_child_stops_and_removes_synthetic_password(self):
        self.prepare_cluster()
        self.harness.write_text('import time\ntime.sleep(60)\n')
        result = e.execute_tests(self.run_dir, timeout_seconds=0.2)
        self.assertEqual(result['status'], 'runner_timeout')
        self.assertFalse(result['scenarios_passed']); self.assertTrue(result['cluster_stopped'])
        self.assertTrue(self.marker.exists()); self.assertFalse((self.cluster/'password').exists())

    def test_process_already_gone_still_cleans_cluster(self):
        self.prepare_cluster()
        fake = MagicMock(pid=999999)
        fake.wait.side_effect = [subprocess.TimeoutExpired('fixture', 0.1), 0]
        with patch.object(e.subprocess, 'Popen', return_value=fake), patch.object(e.os, 'killpg', side_effect=ProcessLookupError), \
             patch.object(e.subprocess, 'run', return_value=subprocess.CompletedProcess([], 0)) as stop:
            result = e.execute_tests(self.run_dir, timeout_seconds=0.1)
        self.assertEqual(stop.call_count, 1); self.assertTrue(result['cluster_stopped'])
        self.assertFalse((self.cluster/'password').exists()); self.assertFalse(result['scenarios_passed'])

    def test_failed_stop_never_approves_and_password_removed(self):
        self.prepare_cluster(); fake = MagicMock(pid=999999)
        fake.wait.side_effect = [subprocess.TimeoutExpired('fixture', 0.1), 0]
        with patch.object(e.subprocess, 'Popen', return_value=fake), patch.object(e.os, 'killpg'), \
             patch.object(e.subprocess, 'run', side_effect=subprocess.TimeoutExpired('stop fixture', 30)):
            result = e.execute_tests(self.run_dir, timeout_seconds=0.1)
        self.assertFalse(result['cluster_stopped']); self.assertFalse(result['scenarios_passed'])
        self.assertFalse((self.cluster/'password').exists())

    def test_post_execution_hash_change_prevents_result(self):
        self.manifest.side_effect = ['hash', ValueError('REVIEWED_FILE_CHANGED')]
        results = {'results': [{'check': x, 'exit': 0} for x in ['version', 'init', 'start', 'Gemini-requested F0-c real PostgreSQL checks', 'stop']]}
        (self.root/f'work/f0b-review-gemini-f0c-{e.BASE[:7]}-{self.run_dir.name}-results.json').write_text(json.dumps(results))
        (self.run_dir/'vitest.json').write_text(json.dumps(report()))
        fake = MagicMock(returncode=0)
        with patch.object(e.subprocess, 'Popen', return_value=fake):
            with self.assertRaisesRegex(ValueError, 'REVIEWED_FILE_CHANGED'): e.execute_tests(self.run_dir)


if __name__ == '__main__': unittest.main()
