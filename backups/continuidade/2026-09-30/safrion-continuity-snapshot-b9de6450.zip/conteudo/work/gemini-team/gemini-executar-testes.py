#!/usr/bin/env python3
"""Gemini aciona uma única ferramenta de teste; nenhuma entrada de shell do modelo é executada."""
import argparse
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import urllib.error
import urllib.request
import uuid

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
MODEL = 'gemini-3.1-pro-preview'
PROJECT = 'project-d6996034-e2ee-4e56-836'
BASE = '228c6c1347ea939c3d48a4057a3d8d9017fcb3ec'
CANDIDATE = BASE
SNAPSHOT = Path('/private/tmp/safrion-f0b-review-228c6c1')
MANIFEST = HERE / 'executor-f0c-manifest.json'
TOOL = 'executar_verificacao_f0c'
TESTS = {
    'duas restaurações sobrepostas geram organizações completas e gerações distintas': 'concorrencia',
    'falha no último cadastro reverte o ponteiro e todos os cadastros da tentativa': 'rollback',
    'restaurar preserva conteúdo de movimento, recibo, auditoria e outbox já confirmados': 'fatos_preservados',
    'aguarda conexão removida por release(error), cujo fechamento ainda está em curso': 'conexao_retirada',
    'encerramento do banco descartável conexão retirada por release(erro) e ainda fechando: encerrar espera o fim real e não a derruba': 'autor_conexao_retirada',
    'encerramento do banco descartável com fechamento lento nos pools do helper, nenhum 57P01 chega a eles': 'autor_fechamento_lento',
    'encerramento do banco descartável conexão que não fecha: encerrar falha com 55006 em vez de derrubá-la': 'autor_conexao_persistente',
}
SYSTEM = ('Você é Gemini, integrante real da equipe Safrion. O agricultor exige testes acionados pelas três IAs. '
          'Você dispõe apenas da ferramenta declarada: ela executa sete testes reais em PostgreSQL local descartável '
          'sobre a candidata por hashes, sem acesso livre ao computador, produção, IAM ou dados reais. '
          'Solicite a ferramenta quando precisar comprovar comportamento; só depois do resultado diga o que foi executado. '
          'Distinguir modelo solicitante e executor local. Falha de teste impede aceite, mesmo com opiniões favoráveis. '
          'Não use aceita ou aceite: informe quantos cenários passaram e os limites. Estes testes não autorizam liberação, HML ou produção. Responda brevemente em português.')
PROMPT = (f'Valide a candidata {CANDIDATE} usando executar_verificacao_f0c. São três provas de demonstração '
          '(concorrência, rollback e preservação dos fatos), uma prova independente de fechamento de conexão retirada '
          'por erro, e três regressões de Claude (conexão retirada, fechamento lento e conexão que não fecha). '
          'A correção remove FORCE do DROP DATABASE no helper: o PostgreSQL espera o encerramento ou falha com 55006 '
          'sem matar a conexão. O caso independente bloqueia client.end, chama encerrar após release(error) e exige '
          'que encerrar não resolva antes da liberação. A execução usa código real, PG17.10 e fixtures sintéticas; não é web/HML hospedada. '
          'Acione a ferramenta e avalie os resultados recebidos. Não apenas sugira que Codex rode os testes.')
DECLARATION = {'name': TOOL, 'description': 'Executa uma vez sete testes reais da candidata fixa em PostgreSQL local descartável; devolve resultados sem logs brutos.',
               'parameters': {'type': 'OBJECT', 'properties': {'candidata': {'type': 'STRING', 'enum': [CANDIDATE]}}, 'required': ['candidata']}}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_manifest():
    m = json.loads(MANIFEST.read_text())
    if m['candidate'] != CANDIDATE or m['base'] != BASE or not m['files']:
        raise ValueError('INVALID_MANIFEST')
    for item in m['files']:
        path = Path(item['path'])
        if not path.is_absolute() or '..' in path.parts or not (path.resolve().is_relative_to(SNAPSHOT.resolve()) or path.resolve().is_relative_to((ROOT / 'work').resolve())):
            raise ValueError('PATH_OUTSIDE_REVIEW')
        if path.is_symlink() or sha(path) != item['sha256']:
            raise ValueError('REVIEWED_FILE_CHANGED')
    return sha(MANIFEST)


def validate_call(call):
    if not isinstance(call, dict) or call.get('name') != TOOL or call.get('args') != {'candidata': CANDIDATE}:
        raise ValueError('TOOL_CALL_NOT_ALLOWED')


def safe_results(report, process_exit, lifecycle):
    assertions = [a for suite in report.get('testResults', []) for a in suite.get('assertionResults', [])]
    observed = []
    for a in assertions:
        name, status = a.get('fullName'), a.get('status')
        if name not in TESTS or status not in ('passed', 'failed', 'pending', 'skipped', 'todo'):
            return {'status': 'invalid_report', 'candidate': CANDIDATE, 'scenarios_passed': False}
        observed.append({'test': TESTS[name], 'status': status})
    complete = len(observed) == len(TESTS) and len({a['test'] for a in observed}) == len(TESTS)
    passed = complete and process_exit == 0 and lifecycle and report.get('success') is True and all(a['status'] == 'passed' for a in observed)
    return {'status': 'executed' if complete else 'incomplete', 'candidate': CANDIDATE, 'scenarios_passed': passed,
            'process_exit': process_exit, 'lifecycle_ok': lifecycle, 'tests': observed,
            'scope': '7 cenarios F0-c em PostgreSQL 17.10 local descartavel; dados sinteticos; sem web, HML ou autorizacao de producao'}


def execute_tests(run_dir, timeout_seconds=900):
    manifest_sha = verify_manifest()
    # Somente o harness revisto; o modelo não fornece caminho, argumentos de processo ou variáveis de ambiente.
    env = {k: os.environ[k] for k in ('PATH', 'LANG', 'TMPDIR') if k in os.environ}
    command = [sys.executable, str(ROOT / 'work/run-f0b-review.py'), 'gemini-f0c', BASE, run_dir.name]
    with (run_dir / 'runner.log').open('x') as log:
        os.chmod(log.name, 0o600)
        p = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            p.wait(timeout=timeout_seconds)
        except subprocess.TimeoutExpired:
            # Grupo exclusivo do harness; nunca sinalizar processos do usuário ou de outro agente.
            try:
                os.killpg(p.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            try:
                p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(p.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                p.wait(timeout=10)
            cluster = Path('/private/tmp/safrion-gemini-pg-' + run_dir.name)
            cfg = json.loads((HERE / 'executor-runtime.json').read_text())
            stopped = not (cluster / 'data/postmaster.pid').exists()
            try:
                if not stopped:
                    stop = subprocess.run([str(Path(cfg['pg']) / 'pg_ctl'), '-D', str(cluster / 'data'), '-m', 'fast', '-w', 'stop'],
                                          stdout=log, stderr=subprocess.STDOUT, env=env, timeout=30)
                    stopped = stop.returncode == 0
            except (OSError, subprocess.SubprocessError):
                stopped = False
            finally:
                (cluster / 'password').unlink(missing_ok=True)
            return {'status': 'runner_timeout', 'scenarios_passed': False, 'candidate': CANDIDATE, 'cluster_stopped': stopped}
    result_file = ROOT / f'work/f0b-review-gemini-f0c-{BASE[:7]}-{run_dir.name}-results.json'
    if not result_file.exists() or not (run_dir / 'vitest.json').exists():
        return {'status': 'missing_result', 'scenarios_passed': False, 'candidate': CANDIDATE, 'process_exit': p.returncode}
    details = json.loads(result_file.read_text())
    checks = details['results']
    lifecycle = len(checks) == 5 and all(x['exit'] == 0 for x in checks if x['check'] != 'Gemini-requested F0-c real PostgreSQL checks')
    report = json.loads((run_dir / 'vitest.json').read_text())
    result = safe_results(report, p.returncode, lifecycle)
    result.update(manifest_sha256=manifest_sha, harness='work/run-f0b-review.py', harness_sha256=sha(ROOT / 'work/run-f0b-review.py'), report_sha256=sha(run_dir / 'vitest.json'))
    verify_manifest()  # Não consolidar evidência se a candidata mudou durante a execução.
    return result


def access_token():
    home = Path.home()
    env = dict(os.environ)
    env['CLOUDSDK_CONFIG'] = str(home / '.config/safrion-gcloud')
    env['CLOUDSDK_PYTHON'] = sys.executable
    result = subprocess.run([str(home / '.local/share/safrion-google-cloud/google-cloud-sdk/bin/gcloud'), 'auth', 'print-access-token'],
                            env=env, cwd='/private/tmp', capture_output=True, text=True, timeout=30, check=True)
    if not result.stdout.strip():
        raise ValueError('AUTHENTICATION_UNAVAILABLE')
    return result.stdout.strip()


def call_model(payload, token):
    url = f'https://aiplatform.googleapis.com/v1/projects/{PROJECT}/locations/global/publishers/google/models/{MODEL}:generateContent'
    request = urllib.request.Request(url, data=json.dumps(payload).encode(), method='POST', headers={
        'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json', 'X-Goog-User-Project': PROJECT})
    with urllib.request.urlopen(request, timeout=180) as response:
        return json.loads(response.read())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    manifest_hash = verify_manifest()
    payload = {'systemInstruction': {'parts': [{'text': SYSTEM}]}, 'contents': [{'role': 'user', 'parts': [{'text': PROMPT}]}],
               'tools': [{'functionDeclarations': [DECLARATION]}], 'toolConfig': {'functionCallingConfig': {'mode': 'AUTO'}},
               'generationConfig': {'candidateCount': 1, 'maxOutputTokens': 16384, 'thinkingConfig': {'thinkingLevel': 'HIGH'}}}
    if args.dry_run:
        print(json.dumps({'model': MODEL, 'manifest_sha256': manifest_hash, 'payload': payload}, ensure_ascii=False))
        return 0
    run_dir = HERE / 'runs' / uuid.uuid4().hex
    run_dir.mkdir(parents=True, mode=0o700)
    record = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'model': MODEL, 'candidate': CANDIDATE,
              'manifest_sha256': manifest_hash, 'request_sha256': hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest(),
              'model_requested_execution': False, 'execution_complete': False, 'scenarios_passed': False, 'calls': []}
    try:
        token = access_token()
        first = call_model(payload, token)
        candidate = first.get('candidates', [{}])[0]
        content = candidate.get('content', {})
        calls = [p['functionCall'] for p in content.get('parts', []) if 'functionCall' in p]
        record['calls'].append({'finishReason': candidate.get('finishReason'), 'modelVersion': first.get('modelVersion'), 'usage': first.get('usageMetadata')})
        if candidate.get('finishReason') != 'STOP' or len(calls) != 1:
            raise ValueError('NO_SINGLE_COMPLETE_TOOL_REQUEST')
        validate_call(calls[0])
        record['model_requested_execution'] = True
        record['functionCall'] = calls[0]
        result = execute_tests(run_dir)
        record['tool_result'] = result
        record['execution_complete'] = result['status'] == 'executed'
        record['scenarios_passed'] = result['scenarios_passed']
        followup = copy.deepcopy(payload)
        response = {'name': TOOL, 'response': {'output': result}}
        if 'id' in calls[0]:
            response['id'] = calls[0]['id']
        # Devolver o conteúdo inteiro preserva thoughtSignature sem expor ou reconstruir raciocínio.
        followup['contents'] += [content, {'role': 'user', 'parts': [{'functionResponse': response}]}]
        followup['toolConfig'] = {'functionCallingConfig': {'mode': 'NONE'}}
        second = call_model(followup, token)
        final = second.get('candidates', [{}])[0]
        record['calls'].append({'finishReason': final.get('finishReason'), 'modelVersion': second.get('modelVersion'), 'usage': second.get('usageMetadata')})
        record['analysis'] = '\n'.join(p['text'] for p in final.get('content', {}).get('parts', []) if p.get('text') and not p.get('thought'))
        record['complete'] = final.get('finishReason') == 'STOP' and bool(record['analysis'])
    except Exception:
        # Nunca imprimir mensagem de exceção: autenticação/driver podem carregar credenciais ou endereços.
        record['complete'] = False
        record['error'] = 'EXECUTION_OR_API_FAILED'
    finally:
        with (run_dir / 'evidence.json').open('x') as file:
            os.chmod(file.name, 0o600)
            json.dump(record, file, ensure_ascii=False, indent=2)
        print(json.dumps({'evidence': str(run_dir / 'evidence.json'), 'execution_complete': record['execution_complete'],
                          'analysis_complete': record.get('complete', False), 'scenarios_passed': record['scenarios_passed']}, ensure_ascii=False))
    return 0 if record.get('complete') and record['scenarios_passed'] else 3 if record.get('complete') and record['execution_complete'] else 1


if __name__ == '__main__':
    sys.exit(main())
