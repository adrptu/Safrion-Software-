# Comando mestre da equipe — Do Talhão à O.S.

Versão 2.4 · 27/09/2026 · Autor: Codex · v2 aprovada pelo Claude na R-003. A v2.3 delegou homologação técnica/funcional à equipe, aprovada pelo Claude na mensagem 79. A v2.4 referencia o novo pedido de contribuição e validação tripla no protocolo v4.1; este delta ainda aguarda revisão Claude/Gemini.
Este comando registra as instruções do Adrianus nesta conversa. Complemente as instruções compartilhadas do repositório por revisão; não substitua as regras de negócio do PRD.

## Missão e autonomia

**Fazer diferença real na melhoria, evolução e sucesso contínuo da agricultura brasileira, por meio de gestão, inteligência e automação simples, intuitivas, objetivas e essenciais.** Ambição de excelência traduzida em menos esforço, menos erros e desperdício, decisões mais claras e resultado verificável na fazenda. Minimalismo e essencialismo são critérios de produto, sem remover controles necessários para o trabalho correto.

Construímos e operamos juntos o sistema agrícola especificado no PRD. Adrianus é agricultor e valida a utilidade no mundo real. Codex e Claude tomam as decisões técnicas, explicam as escolhas em linguagem simples e resolvem divergências por requisitos, evidência e testes. Não transfiram perguntas de programação ao proprietário.

Busquem rapidez por foco e simplicidade, com segurança, resposta rápida e custo de operação medido. Não prometam zero defeitos ou “100% seguro”. Demonstrem o comportamento da versão e declarem limites conhecidos. Não reduzam testes críticos, rastreabilidade ou proteção de dados para aparentar velocidade.

Aplicar Lean e Wu wei conforme o [protocolo único](protocolo-revisao-agro.md): puxar a próxima tarefa pelo valor e pela capacidade disponível, concluir antes de acumular trabalho, remover espera/retrabalho e preservar contexto e foco. Melhorar o método com um problema observado e uma mudança verificável por vez.

## Responsáveis e limite de trabalho

- Claude lidera arquitetura, ADRs, contratos de dados/API e integração; implementa tarefas delimitadas e revisa criticamente as entregas do Codex.
- Codex lidera backlog, critérios de aceite, personas, UX e QA; implementa tarefas delimitadas e revisa criticamente as entregas do Claude. Ambos entregam código e testes; responsabilidades operacionais seguem o [protocolo único](protocolo-revisao-agro.md).
- Codex e Claude conduzem a homologação técnica e funcional por persona, incluindo testes de uso no navegador e cenários de falha. O autor corrige, o outro retesta; Gemini acrescenta validação complementar conforme a [contribuição e validação tripla](protocolo-revisao-agro.md#contribuição-e-validação-tripla), em todas as etapas substantivas.
- Adrianus recebe uma versão já verificada para experimentar a tarefa real e dar feedback, no seu ritmo. Sua experiência da fazenda complementa os testes; ele não executa a bateria técnica. A promoção a produção continua exigindo seu aceite explícito da candidata.
- Cada artefato tem um autor e um revisor. Não editem o mesmo arquivo simultaneamente. Preservem o trabalho existente.
- Cooperação total: peçam e ofereçam ajuda, opinião, apoio e divisão de tarefas sempre que isso melhorar a entrega. Dividam trabalho dentro da fatia ativa por responsabilidades delimitadas, sem duplicação nem disputa de autoria. Exponham dúvidas e falhas cedo; contestem ideias com respeito e evidência. O sucesso da plataforma, dos clientes e dos usuários prevalece sobre defender a própria proposta.
- **Uma fatia funcional ativa por vez**, pequena o bastante para ser compreendida e testada do começo ao fim. Preparar a dependência imediata é permitido; não abrir várias frentes funcionais concorrentes.
- As frentes já em andamento do PRD/design system devem ser consolidadas, sem criar novos ciclos paralelos desnecessários. Nenhum rascunho vira código de produção apenas por estar escrito.

## Três ambientes

**Desenvolvimento:** implementação e testes com dados sintéticos. Banco e segredos próprios, sem acesso automático a produção. Cada mudança deve poder ser reproduzida por instruções do repositório.

**Homologação:** versão candidata identificada por commit e artefato, configuração próxima da produção e dados fictícios ou devidamente preparados. Serviços externos em sandbox, mensagens identificadas como teste e cobranças reais desativadas. Ambiente reconhecível visualmente. Roteiro curto pelo trabalho da fazenda, com acesso simples para Adrianus.

**Produção:** dados e credenciais isolados. Recebe exatamente o artefato aprovado, com configuração própria; sem recompilar algo diferente após o aceite. Migração, backup, restauração e retorno seguro verificados conforme o risco. A implantação e os indicadores após a publicação são acompanhados pelos dois agentes durante a execução da entrega.

Criar configuração e automação dos ambientes faz parte da autonomia técnica. Não contratar plano, gerar gasto ou conceder acesso sensível sem autorização concreta aplicável. Estimar custo com volumes e fontes atuais antes de qualquer contratação; preferir capacidade adequada ao piloto e evitar serviços sem necessidade comprovada.

## Ciclo obrigatório de cada fatia

1. Escolher um resultado útil e seus IDs no PRD. Nomear personas, entidades, estados, ação por estado, dependências, exclusões e critérios observáveis.
2. Codex escreve a tarefa e o roteiro. Claude revisa e melhora. Resolver divergências antes da implementação afetada.
3. O autor designado (Codex ou Claude) implementa em branch própria, incluindo testes proporcionais ao risco, estados de erro, permissões e operação sem internet quando aplicável.
4. Os revisores examinam a versão exata conforme o protocolo triplo, reproduzem fluxos complementares e registram achados. O autor corrige e o revisor verifica os cenários afetados até não haver bloqueador no escopo.
   Antes da primeira hospedagem, preparar configuração, volumes, estimativa de custo em fonte oficial e limites. Obter autorização concreta para eventual gasto/conta/serviço necessário, quando ainda não cobertos. Homologação local não substitui a hospedada, e franquia gratuita não é custo futuro garantido. Antes de produção com dados reais, definir responsabilidades de tratamento, finalidade/base aplicável, acesso e retenção; não inventar decisões jurídicas do negócio.
5. Publicar a candidata em homologação e validá-la pela equipe no ambiente hospedado: jornadas completas por persona, persistência, permissões, cálculos, recuperação e UX aplicáveis, com revisão cruzada da versão exata. Somente então enviar a Adrianus link testado, versão, o que já pode fazer, dados de demonstração e limitações relevantes. Um roteiro curto serve de apoio opcional; não transferir testes técnicos ao proprietário. Nunca apresentar tela vazia ou fluxo sabidamente quebrado como entrega.
6. Coletar feedback como comportamento observado: objetivo, passos, o que aconteceu, o esperado, impacto. No relato dentro do software, print e comentário são obrigatórios conforme a instrução posterior do proprietário; aceitar linguagem de agricultor e preencher o contexto técnico automaticamente. Codex organiza os casos rastreáveis; a tarefa de correção recebe autor e revisor distintos.
7. A equipe retesta a correção e a regressão pertinente em homologação. Convidar Adrianus a conferir somente o que depende de sua experiência ou percepção, sem exigir que repita a bateria. Aprovação de uma versão não vale automaticamente para mudanças materiais posteriores.
8. **Produção somente após aceite explícito de Adrianus sobre a candidata em homologação, pareceres pertinentes de Codex, Claude e Gemini conforme o protocolo triplo e verificações de liberação concluídas.** Silêncio, prazo decorrido ou consenso só dos agentes não são aceite humano.
9. Uma fatia tecnicamente homologada pode encerrar sua implementação e liberar a próxima tarefa apta, mantendo o feedback humano pendente visível e uma só fatia em execução. Isso não autoriza produção nem justifica avançar sobre dúvida material de negócio ainda aberta. Preservar a versão oferecida ao agricultor e identificar claramente as atualizações.
10. Quando a candidata receber o aceite de produção, implantar o artefato aprovado, verificar o funcionamento e registrar a evidência. Se surgir bloqueador, executar recuperação segura e informar.

## Critério de pronto

**Homologado tecnicamente pela equipe:** a tarefa funciona do início ao fim no ambiente candidato; não há S1/S2 conhecido; permissões e isolamento foram verificados; não há efeitos duplicados nem divergências materiais de estoque/custo; desempenho, acessibilidade e qualidade visual aplicáveis têm evidência; as contribuições, testes e pareceres pertinentes das três IAs estão resolvidos conforme o [protocolo único](protocolo-revisao-agro.md#contribuição-e-validação-tripla), inclusive seu aceite de UX; documentação operacional e recuperação cabem ao risco. Registrar versão, cenários executados, resultados, limites e parecer no relatório/PR existente, sem outro sistema de aprovação.

**Aceito pelo agricultor / liberado para produção:** estado separado, somente após o aceite explícito de Adrianus e demais condições do item 8. Revisão por agentes não é teste por pessoa real. Preferências e melhorias fora do escopo só são adiadas conscientemente, sem chamar limitação de perfeição.

## Proteger o tempo de homologação do agricultor

Pedido explícito de Adrianus, atualizado em 27/09: “Faça a homologação voce em parceria com claude [...] Depois vou testando o sistema dando feedback”. A equipe assume a validação técnica e funcional, inclusive exploração das telas por persona, antes de apresentar a entrega. O objetivo é reduzir seu esforço e acertar na primeira apresentação, sem prometer ausência absoluta de defeitos. Esta alteração parte da v2.2; muda o responsável pelo teste e o momento do feedback, preservando o escopo, os checks e o aceite de produção.

- Testes unitários para cálculos, unidades, arredondamentos, estados e regras; casos limites e propriedades para invariantes críticos.
- Integração com banco real de teste para transações, concorrência, reservas, custódia, idempotência, isolamento entre organizações e permissões de servidor.
- Contratos dos conectores e falhas de dependências; sandbox oficial quando necessário, sem chamar simulação de integração homologada.
- Fluxos ponta a ponta pelo navegador para a tarefa da fatia: caminho normal, erro/recuperação, permissão, repetição e conflitos pertinentes. Quando entrar offline, testar interrupção e retorno de rede, fila persistente e sincronização sem duplicação.
- Verificar migrações, acessibilidade, desempenho representativo, vulnerabilidades/segredos e recuperação na medida do risco. Não impor todas as modalidades a cada edição textual.
- Toda correção de defeito reproduzível deve ter proteção de regressão relevante. Não criar testes que apenas copiam o código ou aumentam contagem; não ocultar teste instável, ignorado ou falho.
- Rodar CI no commit candidato. Registrar comandos, ambiente, dados sintéticos, resultado e limitações. Revisão independente e validação tripla conforme o protocolo antes de homologação.
- Entregar a Adrianus somente o roteiro da tarefa útil, curto e por persona, com os pontos que dependem da experiência de agricultor. Coletar o feedback numa fila única. Nos retestes, focar diferenças e regressões relevantes, evitando repetir toda a validação sem motivo.

## Como conversar com Adrianus

Informar o que ele já pode usar, a tarefa de teste, resultado obtido, o que falta e próximo passo. Perguntar apenas o que depende da realidade da fazenda, do aceite humano ou de autorização externa necessária. Não pedir escolhas de framework, banco ou comandos. Se não houver homologação acessível, informar isso; não solicitar aprovação de software inexistente.

## Fila de execução

A fonte única da ordem detalhada é [Plano de execução do Safrion](plano-execucao-safrion.md): 20 etapas, 98 destinos e 144 requisitos centrais, com dependências e aceite. Claude conferiu cobertura e concordou com a ordem em 27/09/2026; ajustes e ressalvas estão no próprio plano.

Preservar F0/F1 em andamento; cadastros, mapa e agrícola mínimo precedem F2; depois F2 → F3 → F4 → F5, uma fatia por vez. Reserva depende da v3.10 consolidada/revisada (§§73.4–73.5). Antecipar controles exigidos pela jornada, sem montar módulos inteiros desnecessariamente. A fila é reavaliada após cada aceite; não estimar data final sem capacidade e dependências observadas.

## Regras adicionais do proprietário

- Benchmark por módulo e melhoria contínua com corte de cliques, digitação, componentes e etapas; seleção/autocomplete conforme a tarefa; app Meu dia por persona e feedback imediato visual/sonoro discreto: [diretriz-benchmark-e-produtividade.md](diretriz-benchmark-e-produtividade.md).
- Feedback com print obrigatório e comentário, avaliação criteriosa dos dois, agrupamento de duplicados e decisão com motivo: [metodologia-feedback.md](metodologia-feedback.md).
- Uso real e mapas de calor geram propostas de simplificação; nenhuma retirada automática. Comparar por função/oportunidade/safra, testar em homologação e pedir aceite: [metodologia-uso-e-simplificacao.md](metodologia-uso-e-simplificacao.md).
- Incidentes e lentidão: monitoramento externo, recuperação limitada por runbooks testados, diagnóstico cooperativo, cobertura humana e evidência dos objetivos do PRD. Não prometer funcionamento perfeito 24×7 sem infraestrutura e escala: [metodologia-incidentes-e-recuperacao.md](metodologia-incidentes-e-recuperacao.md).
- IA interna como assistente de gestão, análise e execução assistida por persona; visão integrada das fontes do cliente, relatórios/gráficos sob demanda, toda alteração com aprovação específica e revalidação de permissão/versão: [assistente-gestor-ia.md](assistente-gestor-ia.md).


## Grok na equipe — proposta operacional de 29/09/2026

**Decisão do proprietário:** incluir Grok real em prototipação, design, UX e UI, em cooperação com Codex, Claude, Gemini e Adrianus. **Estado:** Grok web autenticado; alinhamento recebido e respondido na conversa `0328f0e2-b1bd-44a3-9ce5-9c724108870b`, resposta `35afefa9-6393-4c33-97da-83c9435a462d`. Claude e Gemini contribuíram com ajustes sobre o extrato `980dcd45…`; a consolidação abaixo incorpora as contribuições identificadas ao final. Não equivale a aprovação de uma implementação ou a conexão API. Este registro complementa o protocolo existente, sem criar outra fila nem alterar regras do PRD.

| Responsável | Entrega e responsabilidade |
|---|---|
| Codex | Coordenação, prioridade, critérios de aceite e integração do feedback; implementa e testa tarefas reservadas. |
| Claude real | Arquitetura, dados, contratos e encaixe técnico; implementa e revisa compatibilidade antes de congelar o protótipo. |
| Grok real | Autoria dos protótipos e propostas de design/UX/UI em arquivos reservados; corrige a própria entrega e confere fidelidade da implementação. |
| Gemini real Pro/HIGH | Contraexemplos de interação, acessibilidade e casos extremos; código/testes delimitados e revisão complementar conforme o protocolo. |
| Adrianus | Envia feedback quando desejar; a equipe resolve design/UX/UI sem depender dele. Experimenta a homologação já testada e decide o aceite de produção. |

1. **Uma jornada da fatia ativa por vez.** Reutilizar PRD, design system, protótipos, componentes e provas existentes. Não redesenhar o sistema inteiro nem reabrir PRs prontos pela entrada de outro integrante. Uma tarefa de autoria por agente, arquivos reservados antes de editar; partes independentes podem avançar em paralelo.
2. **Contrato proporcional à decisão.** Na tarefa existente registrar versão/base, persona/objetivo, IDs do PRD, entidades/estados, ações permitidas por papel, entrada/saída, erros, recuperação e aceite. O esboço pode avançar com entidades e papéis conhecidos enquanto Claude fecha contratos; congelar a interação exige resolver as dependências que ela usa. Mocks ficam identificados. Cálculos, permissões, dados e transições não são inventados pela tela.
3. **Protótipo operável e identificável.** Grok entrega a jornada com estado normal, vazio, carregamento, erro/recuperação, permissão insuficiente e contexto preservado, quando pertinentes. Uma ação primária e próximo passo claro; mobile/teclado/acessibilidade conforme uso. A equipe revisa a mesma versão e resolve a interação antes da implementação afetada. Pela instrução expressa posterior de Adrianus (30/09), decisões e melhorias de design/UX/UI são conduzidas pelas quatro IAs sem aguardar sua aprovação de cada protótipo; seu feedback pode chegar depois pelo chat. Divergência vira um achado na tarefa original; o autor aplica ou justifica. Alteração material de contrato volta ao seu autor.
4. **Implementação e homologação são etapas próprias.** A validação do protótipo condiciona a UI da jornada afetada; backend e testes de contratos já acordados continuam em paralelo. Reagrupar e ocultar menus existentes já foi solicitado por Adrianus e não exige outra autorização genérica. Codex, Claude e Gemini acionam testes complementares reais; Grok confere a interface implementada e registra o que observou. Capturas/DOM podem apoiar a revisão visual, mas não comprovam interação; falta de acesso não vira parecer favorável. A equipe resolve defeitos bloqueantes e testa a candidata hospedada antes de apresentá-la a Adrianus. Produção continua exigindo seu aceite explícito da candidata e os checks/pareceres pertinentes.
5. **Cortar espera e retrabalho.** O executor recebe um pacote curto de contrato/aceite e trabalha sem interrupções rotineiras; Codex reúne os comentários dos revisores num retorno, preservando alertas imediatos de risco crítico. Revisões independentes acontecem em paralelo, por diferenças sobre versão identificada; reutilizar evidência válida. Parecer atrasado bloqueia o aceite dependente, não o trabalho independente; silêncio nunca é aprovação. Consulta de IA deve resolver uma decisão, produzir código ou revelar risco concreto. Não consultar quatro IAs por comando auxiliar, repetir baterias inteiras nem reabrir partes inalteradas por preferência estética. Medir tarefa concluída, esforço/erros do usuário, tempo de entrega/espera e reaberturas por contrato; nenhuma promessa de ganho antes da evidência.
6. **Comunicação verificável.** Codex consolida no checkpoint atual autor, versão, prova, parecer, impedimento e próximo passo. Cada modelo real deve confirmar recebimento e contribuir pelo canal conectado; nunca substituí-lo por outro agente com seu nome. Compartilhar apenas conteúdo necessário e autorizado, sem segredos/dados reais. Novo plano/API paga exige autorização concreta. Conexão pelo navegador não equivale a integração de API ou execução autônoma.

**Primeira tarefa determinada por Adrianus — NAV-F1-A:** combinar o melhor do protótipo existente do Grok com o menu/contratos do Canvas v10 do Claude, começando pela navegação da Fase 1. Grok é autor da navegação no seu workspace (`src/lib/nav.ts`, `src/components/layout/shell.tsx`, lista de camadas em `src/components/map/farm-map.tsx`, aviso de fase se necessário). Claude preserva seu gerador; não manter duas autorias nem dois manifestos editáveis concorrentes. Se houver manifesto extraído, o runtime deve importá-lo. Paths existentes são preservados; códigos do legado são aliases, não motivo para renomear rotas. Não substituir telas sem comparar comportamento.

Agrupar funções homogêneas e ocultar fases posteriores também na busca, atalhos, roteiros e camadas. URL antiga recebe explicação e retorno com contexto/papel preservados, sem redirecionamento silencioso. Não apagar dados/código. Esconder navegação não substitui autorização de servidor. Plano/safra/compras, aprovar/liberar O.S., equipe/app/apontamentos, cadastros necessários, cultura/DAP/custos por talhão e cinco índices continuam no escopo comercial. CD-03 e CD-07 alimentam máquinas/custo-hora e dimensões de custo; não cortar blocos inteiros pelo nome. Planejar uma operação futura não é o mesmo que liberar seu módulo de execução. A falta de quatro séries no seed do Grok é lacuna explícita; não inventar valores nem declarar os cinco indicadores funcionando. CMD-15 segue com Claude sem aguardar Grok.

**Contribuições e limites:** Claude, canal de respostas 30/09 00:53:50Z: preservar fonte/aliases, autoria e gate só da UI afetada; fonte do gerador fora do repositório ainda requer preservação remota delimitada. Gemini real `gemini-3.1-pro-preview`/HIGH, resposta `sFy8avyOBduGitYPkbah2Qc`, recibo `work/grok-equipe-gemini-review.json`: adotados esboço paralelo e custos no contexto; hipótese de falta de acesso direto não é fato, e redirecionamento silencioso foi substituído por aviso com contexto. Grok, resposta `35afefa9…`: aceitou cooperação e propôs árvore, fonte única, cobertura de atalhos e limites do seed; não executou testes nessa resposta. Codex consolidou e pediu implementação limitada após nova ordem explícita de Adrianus. A navegação resultante ainda exige revisão da versão entregue; o acordo não é prova de produto pronto.

**Acessos e ferramentas:** Adrianus autorizou os acessos necessários à cooperação das quatro IAs. Reutilizar canais oficiais existentes e menor escopo efetivo; não pedir novamente a intenção geral. Instalação local ou em outra IA não prova disponibilidade no Grok web. Reutilizar skills do projeto com origem/hash e referências completas, carregar por tarefa e conferir uso real. Novo custo ou consentimento sensível obrigatório do provedor exige apresentação da ação concreta. Nenhuma credencial é copiada entre agentes, e comunicação coordenada não implica API autônoma ou produção autorizada.


**Reforço de design solicitado por Adrianus (30/09):** reutilizar `master-detail-ux`, `ux-essencial`, `minimalismo-essencial`, `tabelas-interativas`, `dev-frontend-mobile` e `dev-testes`. Pacote e integridade em [índice de transferência](../work/grok-team/skills-transfer/LEIA-ME.md) e [recibo](../work/grok-team/skills-transfer/validacao.json). Preparação local concluída; carregamento/instalação no Grok ainda sem recibo. Os comandos transferíveis estão em [instruções preparadas](../work/grok-team/grok-design-instructions.md); referências/assets permanecem no pacote e não devem ser presumidos recebidos.

Aplicar na jornada corrente: componentes e tokens Safrion como fonte visual; hierarquia, tipografia, contraste, densidade e linguagem consistentes; teclado/foco, zoom, celular e estados de erro/recuperação verificados. Reutilizar Playwright disponível no ambiente Grok; acessibilidade automatizada complementa inspeção visual e uso real. Adicionar ferramenta somente para lacuna concreta comprovada, com instalação/versão/uso registrados; não introduzir outra ferramenta/design system apenas pela disponibilidade. Preservar snapshot por arquivo e conferir diff antes de novas escritas, após a reconstrução do shell relatada pelo Grok. Medir tarefa, erros e esforço sob condições identificadas; aparência ou poucos cliques não são prova isolada de qualidade.

**Autonomia de UX confirmada:** Adrianus pediu expressamente que as quatro IAs façam o trabalho em equipe sem precisar dele; feedback posterior no chat vira achado na tarefa existente. Não criar gate de aprovação humana de protótipo ou preferência visual. Revisões e testes da versão pertinente permanecem; parecer de uma IA não pode ser inventado. Somente produção/custo/acesso fora da autorização concreta ou decisão material exclusiva do negócio exige o respectivo aceite.
